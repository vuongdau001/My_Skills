# Quy trình quản lý Requirement, Baseline và Development Backlog trên Jira

| Kiểm soát tài liệu | Nội dung |
|---|---|
| Mã tài liệu | CRM-REQ-001 |
| Phiên bản | 1.1 — Bản thảo; Task tập trung vào triển khai |
| Ngày | 02/11/2026 |
| Đối tượng sử dụng | PM, Business/PO, BA, Tech Lead, Dev, QA, người phụ trách Git/CI/deploy |
| Phạm vi | Từ tiếp nhận Feature, làm rõ Epic, khóa yêu cầu và solution, tạo Story/Task đến kiểm chứng và nghiệm thu |
| Tình trạng áp dụng | Quy trình đề xuất; chưa xác nhận cấu hình workflow, quyền và hook trên Jira/Git/CI thực tế |

## 1. Mục tiêu và các quy ước đầu vào

Tài liệu trả lời các câu hỏi:

1. Requirement được phân loại và tổ chức ở đâu?
2. Feature, Epic, Story và Task có trách nhiệm quản lý nội dung gì?
3. **Baseline của tài liệu/nội dung nào phải được duyệt và merge vào Git trước khi tạo Story?**
4. AC, DoR và DoD của từng cấp là gì?
5. Ai chuẩn bị, ai review, ai chốt, ai nhận đầu ra?
6. Dùng các status Jira hiện có để theo dõi công việc như thế nào?
7. Dev và QA nhận bộ đầu vào nào để làm việc bằng AI mà không phải tự đoán requirement?

### 1.1. Những thông tin đã được người quản lý dự án cung cấp

- Cấu trúc quản lý logic: **Feature → Epic → Story → Task**.
- Feature được quản lý trong tài liệu; Jira bắt đầu từ Epic.
- Jira là nơi trao đổi, quản lý công việc và trạng thái thực thi.
- Git là nơi quản lý nội dung chuẩn có phiên bản sau review/phê duyệt.
- PM review và chốt bộ đầu ra đủ điều kiện tạo công việc con/Story.
- AI skill/API/MCP hỗ trợ đọc, comment và thao tác; phải lưu bằng chứng và có gate kiểm bằng máy.

| Issue type hiện có | Các status được cung cấp |
|---|---|
| Epic | `todo`, `inprogress`, `done`, `cancel` |
| Story | `todo`, `inprogress`, `pending`, `resolved`, `done`, `cancel` |
| Task | `todo`, `inprogress`, `review`, `pending`, `resolved`, `done`, `cancel` |

Các định nghĩa và luồng chuyển dưới đây là cách sử dụng đề xuất cho bộ status đó. Danh sách status chưa chứng minh Jira đã cho phép mọi transition được mô tả.

### 1.2. Quan hệ với các tài liệu trước

Tài liệu này ghi lại phương án mới nhất đang thảo luận: **Feature nằm trong tài liệu, phía trên Epic; không yêu cầu issue type Feature trên Jira**. Các ví dụ cũ dùng “Jira Feature” hoặc S0–S3/I0–I3 không phải tên status cần bổ sung vào Jira theo tài liệu này.

Việc đặt Feature trên Epic là quy ước của CRM. Nó khác thứ tự Epic → Feature trong Azure Boards Agile process; phải giải thích quy ước này khi onboarding, không gọi đó là một cấu trúc bắt buộc của Scrum/CMMI.

## 2. Định nghĩa: Requirement, AC, DoR, DoD và Baseline

| Khái niệm | Định nghĩa sử dụng | Ví dụ / hệ quả |
|---|---|---|
| Requirement | Nhu cầu, hành vi hoặc ràng buộc mà giải pháp phải đáp ứng | Người không có quyền không được tạo khách hàng |
| Business Rule — BR | Quy tắc nghiệp vụ có ID, nội dung và nguồn quyết định | BR-CUS-02 quy định phạm vi kiểm tra trùng MST |
| Acceptance Criteria — AC | Điều kiện có thể kiểm chứng để chấp nhận hành vi/kết quả của một phạm vi cụ thể | Request không có quyền bị từ chối và không tạo bản ghi |
| Definition of Ready — DoR | Bộ điều kiện để một loại công việc được bắt đầu ở bước đã xác định | Story đủ rõ, có solution, dữ liệu/dependency và người thực hiện trước khi code |
| Definition of Done — DoD | Bộ điều kiện để xác nhận công việc/đầu ra của một loại đối tượng đã hoàn thành | Story đáp ứng AC, review/test đạt, evidence và tài liệu đầy đủ |
| Baseline | Một tập nội dung xác định đã được review/phê duyệt và được định danh bằng phiên bản; thay đổi sau đó phải được kiểm soát | Bộ yêu cầu + solution của phạm vi manual thuộc Epic CRM-101, tại một Git commit cụ thể |
| Manifest | Danh sách có cấu trúc mô tả phạm vi được chốt và các child dự kiến được phép tạo | Story logical ID, BR/AC thực hiện, dependency và owner |
| Evidence — EVD | Bằng chứng của quyết định, review, thao tác hoặc kiểm chứng thực tế | PR approval, gate receipt, CI run, QA verdict, acceptance record |

### 2.1. Cách phân biệt AC, DoR và DoD

Với Story “AM tạo khách hàng thủ công”:

- **AC:** hệ thống phải làm đúng hành vi nào? Ví dụ, dữ liệu hợp lệ được lưu; người không có quyền bị chặn; dữ liệu trùng được xử lý đúng rule.
- **DoR:** team đã đủ điều kiện bắt đầu triển khai chưa? Ví dụ, “trùng” đã được định nghĩa; solution đã review; có dữ liệu test và dependency cần thiết.
- **DoD:** đầu ra đã đủ chất lượng để đóng Story chưa? Ví dụ, các AC được kiểm chứng; code được review; CI/QA đạt; evidence truy được đúng build.

**Có AC chưa có nghĩa đã đạt DoR. Đạt AC chưa tự chứng minh đạt toàn bộ DoD.**

Các bộ DoR/DoD cho Epic và Task trong tài liệu này là quy định điều chỉnh cho dự án. Trong Scrum Guide, DoD chính thức gắn với chất lượng của Increment; không có một bộ DoR/DoD bắt buộc chung cho mọi cấp Epic/Task.

## 3. Phân loại và phân cấp requirement

### 3.1. Phân loại theo bản chất nội dung

| Loại | Cần mô tả gì? | Ví dụ CRM |
|---|---|---|
| Business requirement | Kết quả tổ chức muốn đạt | Cải thiện độ tin cậy của dữ liệu khách hàng |
| Stakeholder requirement | Nhu cầu của người/nhóm liên quan | AM cần biết khách hàng đã tồn tại và người đang phụ trách |
| Functional requirement | Hành vi hệ thống phải thực hiện | Kiểm tra quyền, phát hiện trùng, lưu và phản hồi |
| Non-functional requirement — NFR | Chất lượng/ràng buộc có cách kiểm chứng | Hiệu năng, bảo mật, tính sẵn sàng hoặc khả năng phục hồi với điều kiện đo rõ |
| Transition requirement | Điều kiện chuyển sang giải pháp mới | Mapping, làm sạch, migration và đối soát dữ liệu |

Đây là các loại nội dung, không phải năm tầng ticket. Một NFR hoặc rule dùng chung có thể áp dụng cho nhiều Epic/Story; các đối tượng đó tham chiếu cùng ID và phiên bản.

### 3.2. Phân cấp theo phạm vi và công việc

| Cấp | Định nghĩa trong CRM | Nội dung cần quản lý | Nơi quản lý |
|---|---|---|---|
| Feature | Phạm vi chức năng nghiệp vụ tổng thể cần theo dõi xuyên suốt | Mục tiêu, scope, yêu cầu dùng chung, danh sách Epic, AC cấp Feature và tiêu chí nghiệm thu tổng thể | Tài liệu Git |
| Epic | Một phần phạm vi của Feature cần làm rõ, thiết kế, triển khai và nghiệm thu | Hồ sơ yêu cầu/solution, owner/readiness từng hạng mục, phương án Story, dependency và nghiệm thu Epic | Jira Epic liên kết tài liệu Git |
| Story | Một lát cắt hành vi có kết quả quan sát và kiểm chứng được | Outcome, phạm vi, BR/AC, solution refs, dependency, estimate và DoR/DoD | Jira Story tham chiếu baseline Git |
| Task | Công việc triển khai, kiểm chứng hoặc hỗ trợ kỹ thuật có đầu ra cụ thể, cần giao/theo dõi riêng | Owner, input, output, reviewer, tiêu chí hoàn tất và evidence | Jira Task |

Ví dụ giả định:

```text
Feature FEAT-CUS-001: Tiếp nhận khách hàng mới
├── Epic: Tiếp nhận bằng nhập thủ công
│   ├── Hồ sơ requirement/AC, solution và testability
│   │   └── Theo dõi owner, readiness, review và evidence ngay trên Epic
│   └── Story: AM tạo khách hàng thủ công trong phạm vi đã chốt
│       ├── Task [DEV]: API và kiểm thử liên quan
│       ├── Task [DEV]: UI và kiểm thử liên quan
│       └── Task [TEST-EXEC]: QA kiểm chứng Story
└── Epic: Tiếp nhận qua import
```

**Đây là quan hệ logic.** Nếu Jira hiện đặt Story và Task cùng cấp, cả hai thuộc Epic; Task triển khai liên kết với Story bằng issue link. Không mặc định Task có thể làm con trực tiếp của Story. Làm rõ requirement, phân tích solution và review testability là hoạt động trên Epic, không tự động tạo Task riêng.

Không bắt mọi Epic phải có nhiều Story hoặc mọi Story phải có nhiều Task. Chỉ phân rã khi giúp giao việc, review hoặc kiểm chứng rõ hơn.

## 4. Baseline của cái gì?

### 4.1. Câu phải dùng trước khi tạo Story

> **Trước khi tạo Story thực thi, phải merge vào Git bộ hồ sơ YÊU CẦU VÀ SOLUTION đã được duyệt của phần phạm vi được chọn trong Epic, kèm kế hoạch phân rã Story được PM chốt.**
>
> Bộ hồ sơ đó gồm mục tiêu/phạm vi, rule, AC, quyết định, solution/contract liên quan, cách kiểm chứng, dependency và manifest Story. Sau merge, bộ hồ sơ tại commit xác định là **baseline đầu vào để tạo Story, development và testing** cho đúng phần phạm vi đó.

Đây không phải baseline của code, không phải chỉ một bản mô tả ticket và không có nghĩa toàn Feature đã phân tích xong.

### 4.2. Phân biệt ba tập nội dung được chốt ở ba thời điểm

| Tập nội dung | Đối tượng được chốt | Dùng để làm gì? | Thời điểm |
|---|---|---|---|
| Khung phạm vi Feature / kế hoạch làm rõ | Mục tiêu, ranh giới sơ bộ, Epic dự kiến, owner, authority và kế hoạch làm rõ | PM cho phép tạo Epic và phân công BA/Dev/QA làm rõ các hạng mục | Trước khi bắt đầu làm rõ Epic; chưa đủ để code |
| **Baseline yêu cầu + solution của phạm vi Epic được chọn** | Nội dung chi tiết nêu tại mục 5 và manifest Story | Cho phép tạo Story; cung cấp đầu vào chuẩn cho Dev/QA/AI | Sau review chuyên môn, PM chốt và PR merge |
| Cấu hình/bản bàn giao triển khai | Code, test, config, migration, artifact/build và release manifest | Chứng minh bản được kiểm thử và bàn giao thực tế | Sau triển khai; không thay thế baseline yêu cầu + solution |

Ví dụ: đã chốt khung “Tiếp nhận khách hàng” thì có thể tạo Epic và giao BA/Dev làm rõ. Các hoạt động này có owner, hạn, capacity và đầu ra ngay trên Epic, không cần Story hoặc Task phân tích có trước. Tuy nhiên, chưa có baseline yêu cầu + solution thì chưa được sinh Story thực thi cho phần đó.

### 4.3. Phạm vi của một baseline

Mỗi baseline đầu vào triển khai phải ghi rõ:

1. Feature ID và Epic liên quan.
2. Phần scope được chọn; phần ngoài phạm vi hoặc còn làm rõ.
3. Danh sách BR-ID, AC-ID và các requirement/NFR dùng chung được áp dụng.
4. Tài liệu solution/contract/UI/data được sử dụng và phiên bản tương ứng.
5. Các quyết định nghiệp vụ/kỹ thuật làm cơ sở.
6. Manifest Story được phép tạo.
7. Review/approval refs đúng phiên bản; PR và Git commit sau merge.

Một baseline có thể chỉ khóa phần độc lập của Epic. Các rule dùng chung mà phần đó phụ thuộc vẫn phải rõ. Không được “bỏ câu hỏi ra ngoài scope” nếu câu trả lời có thể làm thay đổi phần định triển khai.

## 5. Bộ hồ sơ phải review và merge trước khi tạo Story

| Hạng mục trong bộ hồ sơ | Nội dung tối thiểu | Người chuẩn bị / xác nhận |
|---|---|---|
| 1. Định danh và nguồn | Feature/Epic, nguồn nhu cầu, Business authority, owner và tài liệu liên quan | BA; PM/Business xác nhận phạm vi và quyền |
| 2. Mục tiêu và scope | Actor, outcome, trong/ngoài phạm vi; giới hạn phần được khóa | BA + Business |
| 3. Luồng nghiệp vụ | Luồng chính, ngoại lệ, trạng thái và tương tác liên quan | BA; Business chốt; Dev/QA phản biện |
| 4. Rule và dữ liệu | BR-ID, điều kiện, validation, quyền, định danh/chuẩn hóa, trạng thái và xử lý lỗi | BA + Business; Dev kiểm khả thi |
| 5. AC và ví dụ | AC-ID, đầu vào/điều kiện, kết quả mong đợi; happy/negative/boundary/permission theo rủi ro | BA + QA; Business xác nhận expected result |
| 6. NFR và chuyển đổi | Constraint, cách đo, migration/integration/security liên quan; ghi lý do nếu không áp dụng | Dev/TL/QA và đầu mối chuyên môn |
| 7. Quyết định/câu hỏi | Decision refs; câu hỏi chặn đã giải quyết; phần còn mở có owner/hạn và đánh giá tác động | BA giữ hồ sơ; đúng authority chốt |
| 8. Solution | Hiện trạng → delta; thành phần dùng lại/thay đổi; API/data contract, quyền, lỗi/cạnh tranh và rủi ro liên quan | Dev; TL/peer review theo tác động |
| 9. Cách kiểm chứng | Test approach/matrix sơ bộ, dữ liệu/môi trường cần, cách quan sát kết quả và liên kết AC | QA cùng Dev |
| 10. Dependency và điều kiện | Owner hai đầu, contract/version, lead time, việc nào phải sẵn trước code/test | Dev/TL/PM; bên phụ thuộc xác nhận |
| 11. Phân rã Story | Logical ID, outcome, selected BR/AC, scope, dependency, estimate và owner dự kiến | BA + Dev + QA; review INVEST; PM chốt |
| 12. Review và phê duyệt | Ai xác nhận phần nào, revision/digest nào, PR nào và PM decision | Người có thẩm quyền tương ứng |

Không yêu cầu mọi testcase/script chi tiết phải hoàn tất trước baseline. Phải có đủ AC, ví dụ và test approach để xác nhận yêu cầu kiểm chứng được. QA tiếp tục xây chi tiết trong implementation; nếu phát hiện cần đổi expected result thì quay lại quy trình thay đổi.

Tiêu chí nội dung và chất lượng cho từng hạng mục Epic/Story được quy định tại [Chuẩn đặc tả và review Epic/Story](CRM_Epic_Story_Specification_Standard_v1.md). Dùng tài liệu đó để xác định flow, state transition, dữ liệu, quyền, edge case và AC đã đủ rõ hay chưa; có đủ tiêu đề không tự chứng minh đủ nội dung.

Mục 3.3–3.13 của chuẩn đặc tả quy định thao tác review Q01–Q07, evidence, exit criteria và inventory cho từng loại hồ sơ. PM chỉ chốt bàn giao khi các phép kiểm áp dụng có kết luận/evidence đúng revision, không còn gap/câu hỏi chặn; không dùng nhận xét “đã đủ scope” mà thiếu bảng đối chiếu và source/authority review.

### 5.1. Cấu trúc lưu trữ đề xuất

Các đường dẫn dưới đây là cấu trúc đề xuất cho repo dự án, chưa khẳng định đã có repo hoặc các file đó:

```text
docs/
  features/
    FEAT-CUS-001.md                 # Scope Feature, rule chung, Epic refs
  epics/
    EPIC-CUS-MANUAL.md              # Yêu cầu + solution + AC của phần manual
  baselines/
    BASE-CUS-MANUAL-001.yaml        # Selected scope, artifact refs, Story manifest
  shared/
    customer-data-contract.md      # Nếu có contract dùng chung cần tách riêng
```

Có thể gộp yêu cầu, solution và manifest thành các section trong một file Epic khi nhỏ. Điều bắt buộc là **xác định được chính xác tập nội dung/phiên bản được duyệt**, không phải tạo thật nhiều file.

### 5.2. Ví dụ manifest trước khi tạo Story

```yaml
# Ví dụ minh họa, không phải dữ liệu Jira thực tế.
baseline_id: BASE-CUS-MANUAL-001
feature_id: FEAT-CUS-001
epic_ref: <Jira Epic key đã tồn tại>
scope:
  included: Tạo khách hàng thủ công theo các rule được chọn
  excluded: Import khách hàng
artifact_refs:
  - docs/features/FEAT-CUS-001.md
  - docs/epics/EPIC-CUS-MANUAL.md
selected_rules: [BR-CUS-01, BR-CUS-02]
selected_acceptance: [AC-CUS-01, AC-CUS-02, AC-CUS-03]
stories:
  - logical_id: STORY-CUS-MANUAL-01
    outcome: AM tạo hồ sơ hợp lệ, có kiểm quyền và xử lý trùng
    rules: [BR-CUS-01, BR-CUS-02]
    acceptance: [AC-CUS-01, AC-CUS-02, AC-CUS-03]
    solution_ref: docs/epics/EPIC-CUS-MANUAL.md#solution
    dependencies: []  # Chỉ rỗng sau khi đã đánh giá
```

- Logical ID có trước khi tạo ticket; Jira issue key có sau khi API/người thực hiện tạo ticket thành công.
- Không buộc manifest phải có Jira key của Story chưa được tạo.
- Approval lấy từ hồ sơ xác thực của PR/review system; một cờ `approved: true` do AI tự ghi không chứng minh đã được duyệt.
- Git commit sau merge được ghi vào receipt/ticket bàn giao. Không bắt file tự chứa SHA của chính commit đang tạo ra nó.

## 6. Quy trình từ Feature đến Story thực thi

| Bước | Công việc và đầu ra | Người thực hiện / chốt | Trạng thái Jira liên quan |
|---|---|---|---|
| 1. Chốt khung Feature | Ghi mục tiêu, scope sơ bộ, nguồn, Epic dự kiến, owner, authority và kế hoạch làm rõ | BA chuẩn bị; Business xác nhận hướng nghiệp vụ; PM chốt phân rã ban đầu | Có thể tạo Epic `todo` sau khi được phép |
| 2. Giao việc làm rõ Epic | Ghi owner, hạn, capacity, reviewer và output của requirement, solution, testability trong bảng readiness trên Epic | PM phân công; BA/Dev/QA nhận việc | Epic `inprogress` khi bắt đầu; không tạo Task phân tích mặc định |
| 3. Làm rõ requirement | Luồng, rule, AC, dữ liệu, quyền, câu hỏi và quyết định trên Jira | BA chủ trì; Business quyết; Dev/QA góp ý | Cập nhật readiness/evidence của hạng mục requirement trên Epic |
| 4. Phân tích solution | Đối chiếu code/DB, chốt thiết kế, contract, dependency, rủi ro và estimate | Dev; TL/peer và QA review | Cập nhật readiness/evidence của hạng mục solution trên Epic |
| 5. Review testability và chia Story | Xác nhận expected result/cách kiểm chứng; nháp Story theo outcome; review INVEST | BA + Dev + QA | Chưa tạo Story thực thi; dùng section/manifest nháp trên hồ sơ Epic |
| 6. Chuẩn bị PR baseline | Tổng hợp đủ các hạng mục tại mục 5 vào tài liệu Git/PR | BA điều phối; Dev/QA bổ sung phần chuyên môn | Các hạng mục được reviewer xác nhận; Epic vẫn `inprogress` |
| 7. PM chốt và merge | Review chuyên môn đúng revision, PM duyệt phạm vi và manifest; merge PR hợp lệ | Business/BA/Dev/QA xác nhận theo nội dung; PM chốt; người/service có quyền merge | Epic vẫn `inprogress`; chưa phải Epic Done |
| 8. Tạo Story | Đọc manifest từ commit đã merge, tạo đúng child, ghi baseline refs và đối soát kết quả | Người/service được giao; PM kiểm bàn giao | Story được tạo ở `todo` |
| 9. Kiểm DoR Story | Xác nhận đầu vào còn hiệu lực, dữ liệu/dependency/môi trường, owner và capacity | Dev + QA xác nhận; PM chốt kế hoạch | `todo` chưa Ready hoặc `todo` đạt DoR; chỉ triển khai khi đạt |
| 10. Dev, QA và đóng Story | Code/review/CI → deploy/smoke → QA → PM chốt output theo DoD | Dev, reviewer, QA, người deploy và PM | `inprogress` → `resolved` → `done` |
| 11. Nghiệm thu Epic/Feature | Đối chiếu toàn scope và các luồng liên Story/Epic; cập nhật tài liệu và acceptance record | Business nghiệm thu; BA/QA cung cấp hồ sơ; PM chốt roll-up | Epic `done` khi đạt DoD Epic; Feature nghiệm thu trong hồ sơ tài liệu |

Một bàn giao có sender/receiver, input links, revision, output mong đợi và hạn. Người nhận xác nhận nhận việc hoặc trả thiếu có lý do; im lặng không phải approval.

## 7. DoR, AC và DoD của Feature

Feature chỉ ở tài liệu nên các điều kiện dưới đây không tạo thêm status Jira.

### 7.1. DoR để bắt đầu làm rõ/phân rã Feature

- [ ] Có Feature ID, nguồn nhu cầu và mục tiêu nghiệp vụ.
- [ ] Có ranh giới sơ bộ và ưu tiên.
- [ ] Có BA owner, Business authority và PM phụ trách.
- [ ] Có Epic/kế hoạch làm rõ dự kiến và nguồn lực tham gia.
- [ ] PM đã chốt phạm vi giao làm rõ; Business xác nhận hướng nghiệp vụ.

Không đòi toàn bộ rule và solution đã chi tiết ở thời điểm này.

### 7.2. AC cấp Feature

AC mô tả kết quả nghiệp vụ tổng thể và các luồng liên Epic phải đáp ứng. Ví dụ: khách hàng tạo qua manual và import đều tuân thủ cùng quy tắc định danh/phân quyền đã chốt.

### 7.3. Hoàn tất phân tích Feature và DoD bàn giao Feature là hai mốc

| Mốc | Điều kiện |
|---|---|
| Hoàn tất phân tích/phạm vi được khóa | Toàn bộ phạm vi hiện hành đã có yêu cầu, solution, AC và kế hoạch Epic/Story được duyệt tại các baseline tương ứng; không còn câu hỏi chặn |
| Feature Accepted — hoàn tất bàn giao nghiệp vụ | Đủ Epic/phạm vi hiện hành hoàn thành; AC tổng thể và luồng liên Epic đạt; Business nghiệm thu; tài liệu hiện hành cập nhật; vấn đề còn lại được xử lý đúng quyền |

Khóa một phần Feature để làm trước không được báo thành hoàn tất phân tích toàn Feature hoặc Feature Accepted.

## 8. DoR, AC và DoD của Epic

### 8.1. DoR để bắt đầu làm rõ Epic: `todo` → `inprogress`

- [ ] Có liên kết tới Feature và phạm vi Epic được PM chốt cho làm rõ.
- [ ] Có mục tiêu, actor và ranh giới sơ bộ.
- [ ] Có BA, Dev/solution owner, QA và Business authority được chỉ định.
- [ ] Có input/source và khả năng truy cập thông tin cần thiết.
- [ ] Có kế hoạch làm rõ từng hạng mục, owner, reviewer và thời gian thực hiện trên Epic.

**Epic được `inprogress` ngay khi bắt đầu phân tích, không phải đợi bắt đầu code.**

### 8.2. Điều kiện Epic được phép sinh Story thực thi

Đây là cổng bàn giao requirement → development của phần scope được chọn:

- [ ] Bộ hồ sơ tại mục 5 đã đủ cho phần được chọn.
- [ ] Đã review các hạng mục E01–E16 của [chuẩn đặc tả](CRM_Epic_Story_Specification_Standard_v1.md); phần áp dụng có output/verdict, N/A có lý do và người xác nhận.
- [ ] Không còn câu hỏi chặn, bao gồm các rule dùng chung có tác động.
- [ ] Business/BA xác nhận nội dung; Dev/TL xác nhận solution; QA xác nhận testability theo applicability.
- [ ] Story candidates có outcome, BR/AC, scope, dependency và estimate; đã review cách chia.
- [ ] PM đã chốt manifest và bộ đầu ra trên đúng revision.
- [ ] **PR chứa bộ yêu cầu + solution + manifest của phần scope được chọn đã merge vào Git.**
- [ ] Có baseline ID, artifact refs, commit và approval refs để ghi vào Story.

Epic vẫn `inprogress` sau khi đạt cổng này. Đạt điều kiện tạo Story không có nghĩa Epic đã Done và không thay DoR Story.

### 8.3. AC cấp Epic

AC mô tả kết quả tổng thể của phần phạm vi Epic. Ví dụ, luồng tạo manual phải bảo đảm kiểm quyền, validation, xử lý trùng và kết quả lưu/phản hồi nhất quán, kể cả khi được triển khai qua nhiều Story.

AC Epic không được chỉ viết “mọi Story đã Done”; cần chỉ ra kết quả nghiệp vụ phải quan sát được.

### 8.4. DoD để đóng Epic: `inprogress` → `done`

- [ ] Toàn phạm vi Epic hiện hành đã được khóa; không còn phần chưa làm rõ bị bỏ sót.
- [ ] Tất cả Story cần thiết để đáp ứng phạm vi đã `done`.
- [ ] Các Task cần thiết đã hoàn thành; không chỉ đóng ticket để làm đẹp báo cáo.
- [ ] AC Epic và các luồng liên Story được kiểm chứng.
- [ ] Không còn lỗi chặn; vấn đề được hoãn có owner, quyết định và thời hạn hợp lệ.
- [ ] Business có thẩm quyền xác nhận nghiệm thu Epic trên scope/build được định danh.
- [ ] Tài liệu nghiệp vụ/kỹ thuật hiện hành đã cập nhật theo phần mềm thực tế.
- [ ] Có acceptance/evidence links; PM chốt kết quả và báo cáo.

Nếu Feature chỉ có một Epic và đủ cùng phạm vi, có thể dùng một phiên/bản ghi nghiệm thu cho cả hai, ghi rõ các đối tượng được nghiệm thu. Không cần hai nghi lễ trùng nội dung.

## 9. DoR, AC và DoD của Story

### 9.1. DoR để bắt đầu triển khai: `todo` → `inprogress`

- [ ] Story liên kết đúng Epic, Feature và baseline ID/commit.
- [ ] Các hạng mục S01–S12 của [chuẩn đặc tả](CRM_Epic_Story_Specification_Standard_v1.md) có nội dung cụ thể hoặc ref hợp lệ; không sao chép làm lệch baseline Epic.
- [ ] Outcome, trong/ngoài scope rõ; BR/AC và ví dụ có expected result.
- [ ] Solution/contract/UI/data refs phù hợp phạm vi, còn hiệu lực.
- [ ] Dev và QA đã đọc, hiểu khớp; không còn câu hỏi chặn.
- [ ] Dependency phải có trước khi bắt đầu đã sẵn sàng; dependency cho bước sau có cam kết/kế hoạch rõ và không chặn công việc đang nhận.
- [ ] Có dữ liệu/môi trường/quyền cần cho bước thực hiện; điều kiện kiểm thử phía sau có owner và lịch sẵn sàng.
- [ ] Có Dev owner, QA owner, estimate và capacity được xác nhận.
- [ ] Có test approach, policy chất lượng và reviewer cần thiết.
- [ ] PM chốt kế hoạch triển khai, không có blocker còn hiệu lực.

Story có thể đã được tạo nhưng chưa đạt DoR: giữ `todo`, ghi missing items/owner/due. Chưa có `Ready` status thì dùng checklist hoặc nhãn để hiển thị; quyết định gate phải dựa vào evidence, không chỉ nhãn.

### 9.2. AC của Story

AC phải mô tả điều kiện và kết quả có thể quan sát/kiểm chứng. Ví dụ giả định:

| AC | Điều kiện / thao tác | Kết quả mong đợi |
|---|---|---|
| AC-CUS-01 | AM có quyền, gửi dữ liệu hợp lệ không trùng | Tạo đúng một hồ sơ và trả kết quả xác định |
| AC-CUS-02 | Request không có quyền tạo | Bị từ chối; không phát sinh hồ sơ |
| AC-CUS-03 | MST trùng theo rule/phạm vi trạng thái được duyệt | Không tạo hồ sơ trùng; phản hồi theo contract |

Nếu cần ngưỡng hiệu năng hoặc định nghĩa cụ thể về chuẩn hóa/trùng, chúng phải được chốt trong rule/NFR; không để AI tự chọn.

### 9.3. Điều kiện Dev bàn giao QA: `inprogress` → `resolved`

- [ ] Code phù hợp baseline và AC của Story.
- [ ] Peer/TL review cần thiết đã đạt trên đúng revision.
- [ ] Unit/API/permission tests và required CI checks đạt theo policy áp dụng.
- [ ] Build đã được deploy vào môi trường nhận QA; smoke đạt.
- [ ] Có baseline, code SHA, build/config/environment và hướng dẫn kiểm tra liên quan.
- [ ] QA nhận được bộ bàn giao và dữ liệu/slot kiểm thử cần thiết.

Đây là mốc Dev hoàn tất để QA kiểm chứng, **chưa phải DoD của toàn Story**.

### 9.4. DoD đóng Story: `resolved` → `done`

- [ ] Tất cả AC trong phạm vi Story đã được kiểm chứng.
- [ ] Test matrix được duyệt đã thực hiện, kết quả đạt trên build xác định.
- [ ] Không còn Critical/Major mở theo policy dự án; không hạ severity để qua gate.
- [ ] Minor/known issue còn lại có đánh giá tác động và quyết định xử lý đúng thẩm quyền.
- [ ] Code, migration/config và tài liệu liên quan hoàn tất trong phạm vi Story.
- [ ] Evidence truy được baseline → code/review/CI → build → test/defect/verdict.
- [ ] QA xác nhận Pass đúng baseline/build còn hiệu lực.
- [ ] PM hoặc người được ủy quyền chốt bộ đầu ra đủ điều kiện đóng Story.

Không bắt Business nghiệm thu từng Story; Business nghiệm thu Epic/Feature. Nếu QA Pass nhưng chưa có PM closure, Story vẫn `resolved`, ghi rõ đang chờ PM và thời điểm chờ.

## 10. DoR và DoD của Task theo loại đầu ra

Task thuộc backlog triển khai: tạo phần mềm, test, script, cấu hình hoặc bằng chứng kiểm chứng cần thiết. Không mặc định tạo Task `[REQ]`, `[DESIGN]`, `[TEST-DESIGN]` để theo dõi hoạt động làm rõ Epic.

Chỉ tạo Task khi có output cụ thể, owner và nhu cầu giao/theo dõi riêng. Story nhỏ có thể được triển khai trực tiếp, không cần sinh Task cho đủ hình thức. Viết unit test, review code hay cập nhật tài liệu thuộc nghĩa vụ của công việc khi phù hợp; không tự động tạo ticket cho từng thao tác.

### 10.1. DoR dùng chung: `todo` → `inprogress`

- [ ] Có mục tiêu và một đầu ra cụ thể.
- [ ] Có Epic/Story hoặc phạm vi được giao để tham chiếu.
- [ ] Có input/phiên bản cần dùng và quyền truy cập.
- [ ] Có owner, reviewer/người nhận đầu ra, estimate/thời hạn và capacity.
- [ ] Có tiêu chí hoàn tất và phương pháp kiểm tra.
- [ ] Dependency cho bước bắt đầu đã sẵn sàng.
- [ ] Công việc nằm trong kế hoạch được PM xác nhận hoặc trong phạm vi phân rã đã được ủy quyền.

### 10.2. DoD dùng chung

- [ ] Đã tạo đúng đầu ra được giao và đáp ứng tiêu chí hoàn tất.
- [ ] Reviewer phù hợp đã kiểm tra; các finding chặn đã được xử lý.
- [ ] Đầu ra có version/source/evidence và liên kết đúng Epic/Story.
- [ ] Người nhận xác nhận đủ để sử dụng; actual/remaining work được cập nhật.

Không yêu cầu PM đóng từng Task thông thường nếu quyền xác nhận Task đã được phân công. PM vẫn chốt bộ đầu ra tổng hợp ở cổng tạo Story và đóng Story/Epic.

### 10.3. DoD bổ sung theo đầu ra triển khai

| Đầu ra của Task | Đầu ra bắt buộc để Done | Reviewer / người nhận |
|---|---|---|
| Code/API/UI | Code được review/merge theo policy, các kiểm tra liên quan đạt, tích hợp đúng contract, output liên kết Story và code version | Peer/TL; Story owner/QA |
| Automated tests | Expected result được xác nhận, assertion có ý nghĩa, trace BR/AC, script chạy đạt trong môi trường/CI quy định | QA/technical reviewer phù hợp |
| Kiểm thử Story | Các case được giao đã chạy; kết quả, build/data/config refs, Bug/retest và verdict được ghi | QA reviewer/Test Owner; PM nhận verdict tổng hợp |
| Migration/config/CI hoặc hạ tầng hỗ trợ | Artifact/script/config đúng phạm vi; kiểm chứng trên môi trường quy định; có log/đối soát/khôi phục theo rủi ro | Technical reviewer, QA, IT/Data Steward theo nội dung |

Các dòng trên là nhóm đầu ra để chọn tiêu chí, không phải các issue type mới hay bộ Task bắt buộc cho mọi Story. Task Done không tự làm Story Done: Story còn phải được tích hợp và kiểm chứng theo toàn bộ AC/DoD.

### 10.4. Hoạt động refinement và trường hợp nghiên cứu độc lập

Làm rõ requirement, phân tích solution và testability được quản lý bằng readiness/output/review trên Epic. Effort vẫn ghi trên Epic hoặc work package tương ứng; PM cấp capacity và theo dõi thời hạn, không để effort biến mất vì không có Task.

Nghiên cứu nhỏ xử lý trong hoạt động phân tích Epic. Chỉ tạo Task kỹ thuật/spike độc lập khi thật sự cần timebox và đầu ra riêng như PoC, benchmark hoặc script thử nghiệm để ra quyết định. Khi đó PM chốt kế hoạch, TL xác nhận brief/tiêu chí và quyền/dữ liệu; không bắt biết trước solution. Kết quả là evidence/khuyến nghị, không tự được tính là Story hay Feature hoàn thành.

## 11. Ý nghĩa từng status Jira và quy tắc chuyển

### 11.1. Epic

| Status | Ý nghĩa | Điều kiện chính |
|---|---|---|
| `todo` | Đã được phép ghi nhận phạm vi, chưa bắt đầu làm rõ/thực hiện | Có Feature refs, scope sơ bộ và owner |
| `inprogress` | Đang phân tích, thiết kế, triển khai hoặc kiểm chứng | DoR bắt đầu Epic đạt; các Task/Story cho biết đang ở phần nào |
| `done` | Hoàn thành và nghiệm thu phạm vi Epic | Đạt DoD Epic tại mục 8.4 |
| `cancel` | Không tiếp tục phạm vi Epic theo quyết định | Có authority/reason và đánh giá tác động tới Feature |

Epic không có `pending`: giữ `inprogress` và ghi blocker/owner/due trên Epic; Task/Story bị chặn dùng `pending`. Epic bị chặn không được kéo sang `done` hoặc `cancel` chỉ để khỏi hiện việc tồn.

### 11.2. Story

| Status | Ý nghĩa |
|---|---|
| `todo` | Đã tạo từ baseline hợp lệ; chưa triển khai, có thể chưa đạt DoR |
| `inprogress` | Đang code, viết test, review code, xử lý CI hoặc sửa lỗi |
| `pending` | Bị chặn bởi điều kiện cụ thể; có reason, owner, next action và thời điểm chờ |
| `resolved` | Dev đã bàn giao hợp lệ; đang/chờ QA, xử lý kết luận hoặc chờ PM chốt sau QA Pass |
| `done` | Đạt toàn bộ DoD Story |
| `cancel` | Quyết định không triển khai tiếp, không được coi là hoàn thành requirement |

Luồng thông thường:

```text
todo --DoR đạt--> inprogress --Dev bàn giao đạt--> resolved --DoD đạt--> done
                                    ^               |
                                    +-- cần sửa ----+
```

### 11.3. Task

| Status | Ý nghĩa |
|---|---|
| `todo` | Đã giao công việc, chưa bắt đầu |
| `inprogress` | Owner đang tạo đầu ra |
| `review` | Có đầu ra, reviewer đang/chờ kiểm tra |
| `pending` | Bị chặn; có người theo dõi và hành động tiếp theo |
| `resolved` | Review chuyên môn đã đạt, còn một điều kiện bàn giao/xác nhận cuối cụ thể |
| `done` | Đạt DoD Task, người nhận đã xác nhận |
| `cancel` | Dừng công việc theo quyết định hợp lệ |

Luồng thông thường:

```text
todo --DoR đạt--> inprogress --> review --> resolved --> done
                       ^           |
                       +-- sửa ----+
```

Nếu review đã đồng thời đáp ứng DoD và người nhận xác nhận, có thể đi `review → done` khi transition cho phép. Không bắt đi qua `resolved` nếu không có điều kiện chờ thực tế.

### 11.4. Dùng `pending`, trả sửa và `cancel`

- `pending` dành cho bị chặn; không dùng thay mọi hàng đợi thông thường. Task chờ review dùng `review`; Story chờ QA/PM sau bàn giao dùng `resolved`.
- Ghi status trước khi bị chặn và điều kiện resume. Khi có quyết định mới, quay về trạng thái phù hợp; đổi rule cần code lại thì về `inprogress`, không quay thẳng `done`.
- Review/test không đạt mà owner có thể sửa ngay: quay `inprogress`; không tự coi mọi rework là blocker.
- `cancel` cần authority/reason và tác động tới scope/estimate/child. Hủy child không tự loại requirement khỏi scope.
- Mở lại Epic/Story đã Done phải ghi lý do, phạm vi/version và đánh giá lại acceptance; không xóa lịch sử kết quả cũ.

### 11.5. Status `resolved` khác trường Resolution của Jira

Jira còn có trường Resolution, có thể ảnh hưởng báo cáo “đã giải quyết”. Cần kiểm tra category của status, post-functions và cách set/clear Resolution trong workflow thực tế. Với quy ước của tài liệu này, `resolved` chưa được tính Story Done.

Chưa kiểm tra tenant nên tài liệu không khẳng định chỉ đổi cách gọi là báo cáo/hook sẽ tự hoạt động đúng.

## 12. Ai review và ai có quyền chốt?

| Đối tượng / quyết định | Người chuẩn bị | Người xác nhận nội dung | Người chốt chuyển bước |
|---|---|---|---|
| Khung Feature, Epic và kế hoạch phân tích | BA + PM | Business và leads theo phạm vi | PM trong thẩm quyền; vượt quyền trình Sponsor |
| Rule/AC nghiệp vụ | BA | Business có thẩm quyền; Dev/QA phản biện | Business quyết nội dung; PM kiểm đủ điều kiện bàn giao |
| Solution/contract | Dev | Peer/TL theo rủi ro; QA review testability | Technical authority xác nhận; PM không ký thay kết luận kỹ thuật |
| Baseline trước tạo Story | BA điều phối, Dev/QA bổ sung | Các reviewer theo scope/delta | PM chốt manifest và output; merge theo quyền Git |
| DoR Story và kế hoạch triển khai | Dev + QA | Leads xác nhận dependency/capacity khi cần | PM chốt planning |
| DoD Task | Task owner | Reviewer/người nhận được giao | Người được phân công; không mặc định PM cho mọi Task |
| Story `done` | Dev + QA cung cấp evidence | QA xác nhận AC/test; Dev hoàn tất nghĩa vụ kỹ thuật | PM hoặc backup được ủy quyền chốt output |
| Epic/Feature nghiệm thu | BA + QA tổng hợp | Business xác nhận kết quả | PM chốt hồ sơ/roll-up; Business giữ quyền nghiệm thu |

Reviewer được chọn theo loại thay đổi và rủi ro. Nội dung không đổi có thể dùng xác nhận còn hiệu lực, với scope/version rõ; N/A phải có lý do và người chịu trách nhiệm. Không tự bỏ review bắt buộc để tăng tốc.

PM có queue review, thời hạn và backup được ủy quyền. Có thể review theo batch, nhưng quyết định phải riêng cho từng target/revision. Quá hạn không tự trở thành phê duyệt.

## 13. Bàn giao baseline cho người và AI như thế nào?

### 13.1. Sau merge, trước và sau tạo ticket

1. Git ghi nhận commit chứa tập nội dung đã duyệt; service/người phụ trách xác nhận PR/approval đúng revision và kết quả merge.
2. Đọc baseline manifest từ commit đó, không đọc nhánh đang bị sửa tiếp.
3. Tạo Story theo logical ID và scope được PM duyệt.
4. Ghi mapping logical ID → Jira issue key vào execution receipt/Jira, không bắt sửa lại baseline chỉ để thêm key vừa sinh.
5. Trên Story ghi Feature/Epic, baseline ID, repo/path/commit, selected BR/AC, solution/test refs và các approval links.
6. Dev/QA xác nhận nhận đúng bộ đầu vào; bổ sung việc còn thiếu để đạt DoR trước triển khai.

### 13.2. Bộ context tối thiểu cho Dev/QA/AI

```text
Jira Story / Epic / Feature refs:
Baseline ID:
Repo + commit + paths:
Selected scope / ngoài scope:
BR-ID / AC-ID / shared rule refs:
Solution / API / data / UI contract refs:
Test approach / data / environment requirements:
Dependency / owner / reviewer / authority:
DoR / DoD / quality policy:
Phạm vi AI được phép sửa và action được phép thực hiện:
```

AI có thể đọc nguồn, nháp code/test, tìm mâu thuẫn và ghi comment theo quyền được giao. AI phải trả câu hỏi khi thiếu nội dung ảnh hưởng hành vi; không tự xác nhận rule, giả lập QA Pass hoặc ghi cờ PM approval.

### 13.3. Gate kiểm bằng máy

| Hành động | Điều kiện máy cần kiểm |
|---|---|
| Merge bộ baseline | Schema/ref hợp lệ; required review đúng revision; PM approval/authority theo policy |
| Tạo Story | Baseline đã merge, child nằm trong manifest, input refs đúng; idempotency/reconciliation chống tạo trùng |
| `todo` → `inprogress` | DoR evidence còn hiệu lực; owner, dependency/capacity và approval đúng phạm vi |
| Story → `resolved` | Review/CI, deploy/smoke và build refs đạt; đã có bộ bàn giao QA |
| Story → `done` | QA verdict và DoD evidence đúng baseline/build; không có lỗi chặn; PM closure hợp lệ |
| Epic → `done` | Đủ scope, coverage/child completion và Business acceptance; PM chốt roll-up |

Máy kiểm cấu trúc, quyền và bằng chứng đã mã hóa; người có thẩm quyền xác nhận tính đúng của nội dung. Nhãn `dor-ready` hay comment “AI PASS” không tự thay gate.

Danh sách status và template không tự tạo hard gate. Cần khảo sát transition, quyền/bypass và Git/CI để cấu hình validator/service thích hợp. Automation chạy sau khi tạo ticket chỉ hậu kiểm được việc đã xảy ra.

Khi API timeout không biết đã tạo ticket hay chưa: đối soát logical ID/idempotency key rồi mới retry. Evidence/approval service không sẵn sàng thì giữ pending/không chuyển gate; fallback thủ công chỉ khi có policy, authority và evidence tương đương.

## 14. Thay đổi sau baseline

1. Ghi đề nghị/câu hỏi trên Jira, chỉ rõ baseline, scope và lý do.
2. BA/Dev/QA xác định tác động tới rule, AC, solution, Story/Task, test, effort/lịch và acceptance.
3. PM chỉ rõ phần phải dừng; Story/Task bị chặn dùng `pending`, Epic vẫn `inprogress` với blocker nếu chưa hoàn thành.
4. Business/technical authority quyết nội dung; PM/Sponsor quyết scope/nguồn lực theo quyền.
5. Sửa bộ hồ sơ trong PR mới, review lại phần bị ảnh hưởng và merge baseline mới.
6. Cập nhật pin của các Story bị ảnh hưởng sau phê duyệt; chạy lại gate/test cần thiết rồi resume.

Story pin commit và phạm vi cụ thể. Không tự đổi toàn bộ Story sang “commit mới nhất” khi chỉ phần khác của Epic thay đổi. Phần không ảnh hưởng giữ pin cũ khi có đánh giá tác động được xác nhận.

Acceptance/evidence cũ vẫn là lịch sử cho version cũ; không tự chứng minh scope/build mới đạt. Khi Staging đổi build/config/data trong lúc QA/demo, người deploy phải báo và đánh giá lại phần evidence bị ảnh hưởng.

## 15. Theo dõi Requirement Backlog và Development Backlog

### 15.1. Requirement Backlog

Quản lý bằng hồ sơ Feature và Jira Epic, với bảng readiness các hạng mục; không dùng số Task phân tích đã đóng để đo độ rõ requirement. Báo cáo phải cho thấy:

- Feature/Epic nào đã có người làm rõ, ai quyết định nghiệp vụ.
- Requirement/AC đang làm rõ, chờ review hay đã được xác nhận; owner và hạn.
- Solution đang phân tích, chờ review hay đã được xác nhận; owner và hạn.
- QA đã xác nhận testability chưa.
- Câu hỏi/dependency chặn đang chờ ai và bao lâu.
- Phần scope nào đã có baseline yêu cầu + solution hợp lệ; phần nào còn mở.
- PM đã duyệt tạo những Story nào và thực tế tạo được những ticket nào.

Không cần thêm S1/S2/S3 thành Jira status. Độ rõ requirement được xác định từ output, reviewer và baseline evidence, không từ cảm nhận rằng Epic “đã được 70%”.

| Hạng mục trên Epic | Owner | Tín hiệu tiến độ | Đầu ra / xác nhận | Hạn / blocker |
|---|---|---|---|---|
| Requirement và AC | BA | Chưa làm / Đang làm / Chờ review / Đã xác nhận | Spec, decision refs và Business/BA review | Người xử lý và hạn |
| Solution | Dev | Chưa làm / Đang làm / Chờ review / Đã xác nhận | Solution/contract refs và technical review | Người xử lý và hạn |
| Testability | QA | Chưa làm / Đang làm / Chờ review / Đã xác nhận | Coverage/matrix sơ bộ và QA review | Người xử lý và hạn |
| Baseline bàn giao | BA/PM | Chưa trình / Đang review / Đã merge | PR, PM decision và commit/manifest | Người xử lý và hạn |

Các tín hiệu trên là metadata/checklist readiness, không phải Jira status mới. Nếu không có custom field, dùng section thống nhất trong Epic. “Đã xác nhận” phải có người/revision/evidence; Epic vẫn `inprogress` cho đến nghiệm thu. Phần chuẩn đã chốt nằm trong Git; Jira giữ các tín hiệu tiến độ động.

### 15.2. Development Backlog

Theo dõi Story và Task triển khai qua các status đã có:

- `todo`: tách đạt/chưa đạt DoR bằng readiness evidence.
- `inprogress`: workload coding/review/CI và remaining effort.
- `pending`: blocker/owner/age/next action.
- `resolved`: Dev đã bàn giao; phân biệt đang QA, chờ retest hoặc chờ PM closure trong thông tin công việc, không tạo thêm status.
- `done`: đủ DoD; không tính `resolved` là Story Done.
- `cancel`: theo dõi riêng, không cộng vào hoàn thành phạm vi.

Feature không có ticket Jira: tài liệu Git giữ scope, rule, Epic links và baseline refs; dashboard/report tổng hợp trạng thái triển khai bằng cách đọc Jira. Không nhập lại thủ công mọi trạng thái Jira vào tài liệu Git.

Ready buffer phải xét effort/capacity theo từng vai trò và dependency; không cộng BA + Dev + QA effort rồi chia riêng capacity Dev. Chưa có capacity thì không gọi là sẵn sàng triển khai.

## 16. Ví dụ đi hết một vòng: baseline cụ thể của phần manual

Toàn bộ tên, ID và quyết định dưới đây là minh họa, chưa phải rule CRM đã được nghiệp vụ phê duyệt.

### 16.1. Feature và Epic

- Feature `FEAT-CUS-001`: Tiếp nhận khách hàng mới.
- Epic manual có một Jira key thực tế sau khi tạo; ví dụ minh họa dùng `CRM-101`.
- Epic import làm rõ riêng; chưa cần khóa toàn import mới được làm phần manual độc lập.
- PM đã cho phép tạo Epic manual và phân công BA/Dev/QA làm rõ các hạng mục requirement, solution và testability trên Epic; không tạo Task phân tích mặc định.

### 16.2. Đầu ra phân tích và solution

- BR-CUS-01: chỉ người có quyền mới tạo được khách hàng.
- BR-CUS-02: quy tắc chuẩn hóa MST và phạm vi trạng thái phải kiểm trùng đã được Business quyết định.
- AC-CUS-01/02/03: thành công, không quyền và trùng đều có expected result.
- Solution: kiểm ở server để không bypass qua API; có xử lý request đồng thời phù hợp rule.
- QA: có tình huống kiểm chứng, dữ liệu cần chuẩn bị và cách xác nhận không tạo bản ghi thừa.
- Story candidate gồm trọn hành vi tạo manual với quyền/validation/chặn trùng; không đẩy rule an toàn bắt buộc sang một Story sau chỉ để giảm size.

### 16.3. PR phải chứa gì?

PR của phần manual chứa hoặc tham chiếu theo version:

1. Section scope/rule chung cần dùng của `docs/features/FEAT-CUS-001.md`.
2. Hồ sơ yêu cầu + solution + AC của manual trong `docs/epics/EPIC-CUS-MANUAL.md`.
3. Manifest `docs/baselines/BASE-CUS-MANUAL-001.yaml`, chỉ liệt kê Story manual đã được duyệt.
4. Contract/UI/NFR dùng chung cần thiết và decision refs.

Business/BA, Dev/TL và QA xác nhận phần chuyên môn liên quan. PM chốt bộ nội dung và manifest trên revision được review. PR merge thành công tạo commit xác định.

**Baseline lúc này là bộ hồ sơ yêu cầu + solution của manual tại commit đó, được định danh `BASE-CUS-MANUAL-001`.** Nó chưa bao gồm code triển khai và không khóa phần import chưa rõ.

### 16.4. Sau merge và khi triển khai

1. Service đọc manifest từ commit đã merge, tạo Story manual ở `todo` và ghi Jira key vào receipt.
2. Story trỏ tới baseline, selected BR/AC, solution và evidence review.
3. Nếu dữ liệu test cần cho bước triển khai chưa sẵn: chưa đạt DoR, vẫn `todo`, có owner/due chuẩn bị.
4. Đủ DoR và capacity, PM xếp việc; Dev chuyển `inprogress`.
5. Dev code/unit/API tests; Task code qua review theo tiêu chí. Story chỉ `resolved` sau review/CI/deploy/smoke và bàn giao QA hợp lệ.
6. QA phát hiện bypass quyền: ghi issue, Story về `inprogress` để sửa, rồi qua lại review/CI/deploy/retest.
7. QA Pass + đủ DoD + PM chốt: Story `done`.
8. Epic manual chỉ `done` khi đủ toàn scope và Business nghiệm thu. Nếu đây là Story duy nhất, có thể nghiệm thu ngay khi các điều kiện khác đủ.
9. Feature chưa Accepted nếu Epic import trong scope hiện hành chưa hoàn thành.

## 17. Checklist trước khi áp dụng

- [ ] Thống nhất định nghĩa Feature/Epic/Story/Task và quyền của từng người.
- [ ] Xác nhận quan hệ Epic–Story–Task thực tế; chọn link nếu không có parent–child phù hợp.
- [ ] Kiểm transition/status category/Resolution field; bảo đảm `resolved` chưa bị tính thành Story Done theo quy ước dự án.
- [ ] Chọn repo/branch/path; có template Feature/Epic và baseline manifest.
- [ ] Phân công BA/Business/Dev/TL/QA/PM, reviewer và backup có ủy quyền.
- [ ] Chốt policy DoR/DoD, test/coverage/severity theo phạm vi; không coi ví dụ trong tài liệu là ngưỡng đã duyệt.
- [ ] Chốt nguồn evidence, quyền và retention; cấu hình required checks/validator/service và các đường bypass.
- [ ] Pilot một Epic nhỏ, có cả đường bình thường và trường hợp thiếu input/đổi rule/API retry.
- [ ] Kiểm người nhận tìm được đúng baseline, hiểu đúng AC, biết ai quyết và không bị kẹt ở vòng approval.

## 18. Tài liệu tham khảo

Các nguồn giúp định nghĩa khái niệm; workflow, hierarchy Feature-trên-Epic và các checklist của CRM trong tài liệu này là đề xuất điều chỉnh cho dự án:

- [IIBA — Global Business Analysis Core Standard](https://www.iiba.org/globalassets/standards-and-resources/core-standard/iiba-core-standard.pdf): phân loại và quản lý requirement.
- [Scrum Guide 2020 — Definition of Done](https://scrumguides.org/scrum-guide.html#commitment-definition-of-done): DoD gắn với chất lượng Increment.
- [Scrum Alliance — Definition of Ready vs. Definition of Done](https://resources.scrumalliance.org/Article/definition-vs-ready): phân biệt điều kiện bắt đầu và hoàn thành.
- [Scrum Alliance — Agile Glossary](https://www.scrumalliance.org/glossary/): Acceptance Criteria.
- [Scrum Guide — Product Backlog và refinement](https://scrumguides.org/scrum-guide.html#product-backlog): refinement là hoạt động làm rõ backlog; cách phân rã công việc được điều chỉnh theo nhu cầu của đội. Việc không tạo Task phân tích mặc định trong tài liệu này là quyết định tổ chức đề xuất cho CRM.
- [Microsoft — Define features and epics](https://learn.microsoft.com/en-us/azure/devops/boards/backlogs/define-features-epics?view=azure-devops): ví dụ hierarchy Epic → Feature của Azure Boards, để phân biệt với quy ước CRM.
- [Atlassian — Configure the work type hierarchy](https://support.atlassian.com/jira-cloud-administration/docs/configure-the-issue-type-hierarchy): các mức work item và giới hạn cấu hình.
- [Atlassian — Best practices on the Resolution field](https://support.atlassian.com/jira/kb/best-practices-on-using-the-resolution-field-in-jira-cloud/): ảnh hưởng của Resolution đối với trạng thái “resolved” trong hệ thống.
