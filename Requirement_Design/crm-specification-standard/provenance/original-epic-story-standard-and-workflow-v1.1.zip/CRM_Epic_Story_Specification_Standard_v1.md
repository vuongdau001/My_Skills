# Chuẩn đặc tả và review Epic / Story cho dự án CRM

| Kiểm soát tài liệu | Nội dung |
|---|---|
| Mã tài liệu | CRM-SPEC-001 |
| Phiên bản / ngày | 1.1 — Bổ sung thủ tục kiểm và điều kiện kết luận, 02/11/2026 |
| Mục tiêu | Xác định Epic/Story cần nội dung gì và tiêu chí nào chứng minh nội dung đủ rõ để bàn giao |
| Người sử dụng | BA, Business/PO, Dev/TL, QA và PM |
| Tài liệu quy trình liên quan | [Requirement, Baseline và Workflow Jira — bản 1.1](CRM_Requirement_Baseline_Jira_Workflow_v1.md) |
| Phạm vi bước này | Chuẩn nội dung và review; làm cơ sở thiết kế skill sau khi thống nhất chuẩn |

## 1. Nguyên tắc sử dụng

1. **Epic mô tả phạm vi nghiệp vụ và solution tổng thể; Story mô tả chính xác phần hành vi sẽ triển khai.** Story tham chiếu nội dung dùng chung đã khóa của Epic, không chép lại thành một bản khác dễ lệch.
2. Có đủ tiêu đề hoặc AI điền hết template chưa chứng minh nội dung đúng/đủ. Mỗi hạng mục cần output, nguồn, reviewer, kết quả review và phiên bản.
3. Mọi nhóm nội dung trong checklist phải được đánh giá applicability. Nhóm có điều kiện có thể ghi N/A với lý do và người xác nhận; chưa biết không được đổi thành N/A.
4. Mức chi tiết theo phạm vi và rủi ro. Không bắt sửa một nhãn UI phải vẽ BPMN, sequence diagram và state machine mới.
5. Nội dung chuẩn nằm trong bộ yêu cầu + solution được baseline trong Git. Jira Epic giữ trao đổi, owner, readiness và blocker; không tạo Task phân tích mặc định.
6. “State transition” ở tài liệu đặc tả là vòng đời **đối tượng nghiệp vụ** như yêu cầu phê duyệt. Nó khác status Jira `todo/inprogress/resolved/done` của công việc triển khai.
7. Đánh giá “đủ” trong phạm vi được duyệt, trên những mô hình/rủi ro đã xác định; không tuyên bố một checklist hữu hạn chứng minh mọi tình huống có thể xảy ra ngoài đời đã được biết hết.

## 2. Cơ sở chuẩn và cách áp dụng

| Nguồn chính thức | Phần tham khảo | Cách sử dụng trong CRM |
|---|---|---|
| [ISO/IEC/IEEE 29148:2018](https://www.iso.org/standard/72089.html) | Requirements engineering và nội dung thông tin liên quan | Cơ sở tổ chức hồ sơ yêu cầu; không tuyên bố bảng Epic/Story dưới đây là template nguyên văn của ISO |
| [IREB CPRE Glossary](https://cpre.ireb.org/en/downloads-and-resources/glossary) | Completeness, consistency, verifiability và validation | Phân biệt đủ nội dung trong scope, không mâu thuẫn, kiểm chứng được và đúng nhu cầu |
| [IREB CPRE Foundation syllabus 3.3.0, mục 3.8 và 4.4](https://hub.ireb.org/media/pages/resources/cpre-foundation-level-syllabus/9c084b1cfd-1787039954/cpre_foundationlevel_syllabus_en_v.3.3.0.pdf) | Quality criteria ở hai mức và cách validation | Bổ sung quality review từng requirement và cả bộ hồ sơ, có stakeholder, góc nhìn và review lặp |
| [NASA Systems Engineering Handbook, Appendix C](https://www.nasa.gov/reference/appendix-c-how-to-write-a-good-requirement/) | Checklist viết và validation requirement, nhất là C.4 | Tham khảo các câu hỏi kiểm thực tế, rồi điều chỉnh thành thủ tục review CRM |
| [OMG BPMN 2.0.2](https://www.omg.org/spec/BPMN/2.0.2) | Ký pháp mô hình quy trình nghiệp vụ | Dùng khi cần làm rõ trách nhiệm, sự kiện, nhánh và phối hợp nhiều bên |
| [OMG UML 2.5.1](https://www.omg.org/spec/UML/2.5.1) | Ký pháp mô hình, gồm hành vi/trạng thái/tương tác | Tham khảo khi dùng state machine hoặc sequence diagram; phải phân biệt diagram minh họa và mô hình đúng ký pháp |
| [ISTQB CTFL v4.0.1, mục 4.2](https://istqb.org/wp-content/uploads/2024/11/ISTQB_CTFL_Syllabus_v4.0.1.pdf) | Equivalence partitioning, boundary values, decision tables, state transitions | Kỹ thuật rà thiếu test condition và phản ví dụ từ mô hình; không biến số testcase thành bằng chứng spec đúng |

ISO công khai xác định phạm vi quá trình và information items của requirements engineering. Bảng chi tiết dưới đây là **chuẩn nội bộ đề xuất cho CRM**, được điều chỉnh từ các nguyên tắc/kỹ thuật tham khảo. Chưa đối chiếu toàn văn trả phí để kết luận tuân thủ điều khoản ISO, và không có một checklist Epic/Story duy nhất bắt buộc cho mọi dự án.

## 3. Cách kết luận một hạng mục đã đạt

### 3.1. Cấu trúc review dùng chung

Mỗi hạng mục E/S bên dưới có bản ghi:

| Trường | Nội dung |
|---|---|
| Applicability | Áp dụng / N/A có lý do và người xác nhận |
| Phạm vi và phiên bản | Epic/Story, phần scope, section/model ID, revision hoặc baseline ref |
| Output | Đường dẫn, section, bảng hoặc mô hình cụ thể |
| Owner / reviewer | Người viết và người có năng lực/quyền xác nhận |
| Review result | Chưa kiểm / Không đạt / Đạt / N/A có lý do; ghi finding và reason |
| Open question | Câu hỏi, tác động, owner, hạn và có chặn scope này không |
| Decision/evidence | Nguồn nghiệp vụ, approval, review comments hoặc record tương ứng |

Các giá trị review này là metadata nội dung, không phải status Jira mới.

### 3.2. Bảy nhóm kiểm thực hành và phạm vi nguồn tham khảo

| Nhóm kiểm | Cần chứng minh gì? | Ví dụ không đạt |
|---|---|---|
| Q01 — Đúng nhu cầu và cần thiết | Nội dung có nguồn, rationale và đúng authority xác nhận | BA/AI tự quyết ai được duyệt yêu cầu |
| Q02 — Đủ trong scope | Đủ phát biểu đơn lẻ và không bỏ sót phần đã biết của tập yêu cầu; có inventory và disposition | Chỉ có happy path, chưa xét trạng thái sai hoặc quyền sai |
| Q03 — Nhất quán | Các phát biểu/mô hình cùng điều kiện không cho kết quả mâu thuẫn | Flow cho người tạo tự duyệt nhưng permission matrix cấm |
| Q04 — Kiểm chứng được | Có setup/input, expected result và phương pháp quan sát/đo/xét đạt | “Nhanh”, “đúng”, “thân thiện” mà không có điều kiện đo/quan sát |
| Q05 — Truy vết và quản lý phiên bản | Có ID/source/dependency/version và liên kết phù hợp giai đoạn | Story ghi “theo rule hiện tại” nhưng không biết rule nào, version nào |
| Q06 — Không mơ hồ, hiểu được, tách nghĩa rõ | Người đọc độc lập hiểu cùng nghĩa; điều kiện/đơn vị/phạm vi rõ | “AM được sửa hồ sơ nếu phù hợp” nhưng không rõ hồ sơ nào, điều kiện nào |
| Q07 — Khả thi và đúng mức bàn giao | Có cơ sở thực hiện/kiểm chứng trong các constraint được giao | Solution phụ thuộc API/quyền chưa tồn tại nhưng được ghi đã khả thi |

Đây là cách nhóm phép kiểm **do CRM đề xuất**, không phải danh sách “bảy tiêu chí” nguyên bản của một framework. Bản 1.0 chỉ có năm nhãn tổng quát; bản 1.1 tách thêm Q06/Q07 để tránh bỏ qua nghĩa mơ hồ và feasibility.

IREB mục 3.8 phân biệt tiêu chí cho một requirement với tiêu chí bổ sung cho bộ hồ sơ, gồm cả non-redundant, modifiable và conformant; danh sách là khuyến nghị không mang tính bao trùm mọi hoàn cảnh. Trong CRM, các mặt này được kiểm ở Q03/Q05/Q06 và kiểm cấu trúc; không gọi năm nhãn cũ là toàn bộ chuẩn IREB. [IREB syllabus](https://hub.ireb.org/media/pages/resources/cpre-foundation-level-syllabus/9c084b1cfd-1787039954/cpre_foundationlevel_syllabus_en_v.3.3.0.pdf).

NASA Appendix C.4 đưa các câu hỏi validation cụ thể; ISTQB cung cấp kỹ thuật review/test design và coverage. Các bước, bảng inventory, ngưỡng dừng và ví dụ CRM từ mục 3.3 trở đi là cách vận dụng của dự án, không phải quy trình sao chép nguyên văn hay kết luận tuân thủ ISO. [NASA](https://www.nasa.gov/reference/appendix-c-how-to-write-a-good-requirement/), [ISTQB](https://istqb.org/wp-content/uploads/2024/11/ISTQB_CTFL_Syllabus_v4.0.1.pdf).

### 3.3. Chuẩn bị review và quy tắc kết luận

**Đơn vị review:** một requirement, một nhóm rule/model hoặc toàn bộ scope được chọn của Epic/Story. Ghi rõ target và revision trước khi kiểm; “review Epic rồi” không xác định được bộ nội dung nào đã được xét.

**Bộ đầu vào:** scope/source register, danh sách actor và authority, nội dung E/S áp dụng, model/contract refs, câu hỏi/quyết định, baseline cha và danh sách delta. Nếu chưa có input cần thiết, ghi `Chưa kiểm — thiếu input`, không ghi Đạt.

**Thực hiện:** owner chuẩn bị inventory; BA/Business, Dev/TL và QA kiểm từ các góc nhìn tương ứng. Người phát hiện ghi finding với vị trí/điều kiện/counterexample; owner sửa; reviewer xác nhận closure. PM xem kết quả/evidence và rủi ro, không thay kết luận của người chuyên môn.

| Kết quả | Khi dùng | Có qua gate không? |
|---|---|---|
| Đạt | Đã làm các bước áp dụng và có evidence đáp ứng exit criteria | Có thể, nếu mọi điều kiện gate khác đủ |
| Không đạt | Có counterexample, thông tin thiếu hoặc kết luận không có cơ sở | Chưa, đối với phần bị ảnh hưởng |
| Chưa kiểm | Chưa review hoặc thiếu input/người có authority | Chưa; không chuyển thành Đạt chỉ vì không thấy lỗi |
| N/A | Phép kiểm/hạng mục thực sự không áp dụng, có lý do và reviewer xác nhận | Chỉ cho đúng phần N/A; không miễn các yêu cầu bắt buộc khác |

**Điều kiện đóng một review target để bàn giao:**

- Mọi phép kiểm áp dụng đã có kết luận Đạt và evidence, không còn ô chưa kiểm/không biết bị che bằng N/A.
- Không còn finding/câu hỏi làm thay đổi expected behavior, quyền, state/data, contract, control bắt buộc hoặc feasibility của scope chọn mà chưa được giải quyết.
- Lỗi biên tập không ảnh hưởng ý nghĩa có thể thành action không chặn với owner/hạn; không gọi finding ngữ nghĩa chưa sửa là Đạt chỉ vì PM chấp nhận thời gian chờ.
- Mọi phần loại khỏi scope/không áp dụng có quyết định và đánh giá dependency; không loại case khỏi inventory chỉ để tỷ lệ coverage đẹp.
- Verdict gắn đúng revision. Delta sau review phải đánh giá tác động và kiểm lại phần liên quan; không tự tái dùng approval cũ cho nội dung mới.

Không tính điểm trung bình giữa các phép kiểm. Q01 sai nghiệp vụ không được bù bằng Q05 có đủ link.

### 3.4. Q01 — Kiểm đúng nhu cầu và sự cần thiết

**Câu hỏi cần trả lời:** requirement này thể hiện đúng điều được cần/được quyết định chưa, và có thuộc phạm vi được giao không?

**Các bước reviewer thực hiện:**

1. Từ từng BR/AC/constraint, mở parent need hoặc decision/source đã dẫn; kiểm nguồn có authority và còn hiệu lực cho scope này.
2. Ghi mục đích của requirement: nếu bỏ nó thì mục tiêu/control nào không đáp ứng? Nếu không giải thích được, yêu cầu BA làm rõ rationale thay vì tự kết luận cần thiết.
3. Business đọc lại bằng một ví dụ thành công và phản ví dụ/từ chối, chốt expected result; QA/Dev đối chiếu cách hiểu. Với yêu cầu kỹ thuật/control, đúng technical/control authority xác nhận.
4. Tách requirement nghiệp vụ khỏi lựa chọn thiết kế. Nếu một công nghệ/giải pháp là constraint bắt buộc, ghi nguồn/authority của constraint; nếu chỉ là phương án, chuyển sang solution/rationale.
5. Khi nguồn/nhóm stakeholder mâu thuẫn, ghi conflict và người phân xử; không chọn ý kiến cuối cùng trong comment làm chân lý.

**Evidence:** link nguồn/parent, rationale, ví dụ + phản ví dụ, authority/verdict đúng revision; conflict đã đóng.

**Đạt khi:** mỗi yêu cầu trong target có rationale/source được chấp nhận, đúng scope và có authority xác nhận nghĩa/expected result. **Không đạt khi:** chỉ có nhãn Approved, chỉ có BA/AI tự suy ra hành vi hoặc chưa giải quyết xung đột.

**Ví dụ:** rule “người tạo được tự duyệt” không Đạt chỉ vì được diễn đạt rõ. Business/control owner phải xác nhận có cho tự duyệt hay không và phạm vi nào; kết quả đó mới làm cơ sở model/quyền/AC.

### 3.5. Q02 — Kiểm đầy đủ ở hai mức

#### A. Đủ một phát biểu/requirement đơn lẻ

Đọc từng BR/AC và điền hoặc tham chiếu có định danh tới:

1. Ai/hệ thống nào thực hiện; action/command nào, trên đối tượng/dữ liệu nào.
2. Trigger/preconditions và phạm vi điều kiện: state, quyền, dữ liệu, thời gian/kênh liên quan.
3. Kết quả có thể quan sát: response, state/data thay đổi hoặc không đổi, side effects liên quan.
4. Các giới hạn/ngoại lệ ảnh hưởng kết quả và kết quả khi điều kiện không đạt.
5. Thuật ngữ/đơn vị/giá trị cần để hiểu đầy đủ; phần kế thừa dẫn đúng model/contract/version.

Không phải ép cả năm ý vào một câu dài; có thể diễn đạt trong nhóm hồ sơ có liên kết. Tuy nhiên, người đọc phải tìm được câu trả lời xác định, không phải suy đoán hoặc đọc một nguồn “latest” không pin.

**Ví dụ thiếu:** “Hệ thống kiểm tra trùng MST”. Còn thiếu định nghĩa chuẩn hóa, tập hồ sơ so sánh, trạng thái/tenant áp dụng, kết quả khi trùng và cách xử lý hai request cạnh tranh nếu có thể xảy ra.

#### B. Đủ cả bộ yêu cầu trong scope

Reviewer thực hiện theo thứ tự sau:

1. **Chốt đường biên và nguồn:** actor/đầu mối nghiệp vụ, hệ thống giao tiếp, tài liệu hiện hành, constraint và phần thay đổi. Đối chiếu với thực tế/legacy và hỏi người vận hành về ngoại lệ đã biết; code hiện tại là nguồn phát hiện, không tự động là yêu cầu đúng.
2. **Lập inventory cần rà** theo các chiều dưới đây và các đơn vị model tại mục 3.11. Inventory là danh sách có ID/định nghĩa, không chỉ một tiêu đề “đã xem edge case”.
3. **Gán disposition cho từng item:** đã đặc tả trong scope, kế thừa baseline nào, ngoài scope theo quyết định nào hoặc không khả thi/N/A với lý do nào. Unknown/TBD là gap cần xử lý, không phải disposition hợp lệ để qua gate nếu chặn scope.
4. **Nối tới output và verification:** mỗi item trong scope phải tìm được rule/model/AC và test condition/phương pháp kiểm phù hợp. Một item có nhiều refs, không bắt tạo một AC trùng cho mỗi ô.
5. **Kiểm lỗ hổng và câu hỏi:** QA dùng inventory để tìm counterexample; Business/Dev xác nhận phần thiếu hoặc lý do loại trừ. Câu trả lời mới làm đổi tập item thì cập nhật inventory và rà lại phần ảnh hưởng.
6. **Kết luận với mẫu số nhìn thấy:** ghi số item trong từng tập, số đã có disposition, số chưa quyết và số thiếu verification mapping. Reviewer ký nhận inventory/phạm vi; không tuyên bố “mọi tình huống ngoài đời đã đủ”.

| Chiều inventory | Reviewer phải liệt kê tối thiểu gì? | Câu hỏi tìm thiếu |
|---|---|---|
| Nguồn/actor | Nhóm người, owner dữ liệu, control/operations và counterpart có tác động | Có ai nhận output hoặc gánh lỗi mà chưa được hỏi không? |
| Chức năng và flow | Use cases/commands, trigger, input/output, nhánh điều kiện và kết thúc | Sau một nhánh lỗi, dữ liệu/state nằm ở đâu? Ai xử lý tiếp? |
| Business state | Tập state, tập command và state–command disposition | Lệnh mới ở trạng thái không hợp lệ, replay và guard fail đã có kết quả chưa? |
| Rule/data | Condition domains, fields, valid/invalid groups, boundaries, cross-field constraints | Có giá trị/tổ hợp hợp lệ nào chưa biết xử lý? Có loại trừ giả để giấu gap không? |
| Quyền | Role/action/resource/ownership/state và policy default | Đúng role nhưng sai owner/state thì sao? |
| Integration | Đầu giao tiếp, successful/failure/timeout/duplicate/order và commit boundary | Lỗi trước và sau commit có bị mô tả giống nhau dù dữ liệu đã khác không? |
| NFR/transition | Control, tải/thời gian, dữ liệu chuyển đổi, khôi phục, audit/support có liên quan | Mục tiêu nghiệp vụ có đạt nếu functional đúng nhưng control/vận hành không đáp ứng không? |

**Evidence:** inventory version, disposition/coverage matrix, source/decision links, gap log và review từ các góc nhìn.

**Đạt khi:** trong scope/inventory đã được xác nhận, không còn item bắt buộc chưa có disposition/nội dung, không có câu hỏi chặn và không có requirement liên quan đã biết bị bỏ sót. **Không đạt khi:** chỉ đủ 16/16 section nhưng transition/permission/error còn ô chưa quyết.

“Đủ trong scope” có nghĩa reviewer đã thực hiện quy trình trên, không phải được quyền tự cảm nhận rằng spec có vẻ đầy đủ.

### 3.6. Q03 — Kiểm nhất quán giữa các phát biểu và mô hình

**Cách kiểm:**

1. Chọn cùng một action và một bộ điều kiện cụ thể: actor, resource/owner, state/version, input và thời điểm/sequence liên quan.
2. Lần theo flow → state/decision → data/permission → contract → AC. Ghi bảng so sánh với ref cho từng output/guard.
3. So các expected result: allow/deny, target state, data mutation, response, audit/notification và recovery. Nếu cùng điều kiện dẫn hai kết quả trái nhau, mở finding.
4. So với parent/shared baseline. Kiểm alias/thuật ngữ, đơn vị/timezone, thứ tự ưu tiên rule và NFR. Hai requirement trùng nghĩa phải hợp nhất hoặc dẫn chung, không giữ hai bản độc lập rồi sửa lệch.
5. Business/technical authority giải quyết conflict; owner cập nhật mọi representation liên quan, reviewer kiểm lại cùng counterexample trước đóng finding.

| Action + điều kiện | Flow ref/result | Rule/state ref/result | Permission/contract ref/result | AC ref/result | Conflict / closure |
|---|---|---|---|---|---|
| Creator tự approve, hồ sơ Pending | … | … | … | … | … |

**Evidence:** cross-model comparison, conflict log và revision sau sửa. **Đạt khi:** các điều kiện áp dụng cho cùng tình huống cho kết quả tương thích; không có contradiction chưa giải quyết. **Không đạt khi:** nguồn nào cũng có chữ “approved” nhưng cho kết quả khác nhau.

**Ví dụ:** flow cho approve, permission cấm creator, AC chỉ nói success. Sửa một câu AC chưa đủ; phải sửa cả flow/guard/contract hoặc quyết định lại policy rồi rà toàn bộ refs.

### 3.7. Q04 — Kiểm khả năng kiểm chứng

**Cách kiểm từng requirement/AC:**

1. Viết một verification sketch: tạo actor/resource/state/data nào, gửi action/input nào và quan sát qua kênh nào.
2. Liệt kê expected response, state/data sau thao tác và side effects cần có/không được có. Chọn cách quan sát hợp lệ: API/readback, UI, event/log, measurement hoặc inspection phù hợp.
3. Xác định tiêu chí phân biệt Pass/Fail: values/ranges, control, ordering hoặc invariants; với NFR ghi workload, environment, khoảng đo và authority chốt ngưỡng.
4. Xét ít nhất case đáp ứng và case vi phạm điều kiện khi có ý nghĩa, thêm boundary/failure theo inventory. Kiểm rằng phép đo/assertion sẽ phát hiện một implementation sai, không chỉ `assert true` hoặc kiểm toast chung.
5. QA xác nhận expected result với Business/contract và tính quan sát được với Dev. Nếu cách kiểm cần access/test hook/data chưa có thì đưa sang Q07/dependency, không ghi “test sau”.

**Evidence:** verification sketch/test condition, expected outcome, data/environment/measurement requirements và reviewer.

**Đạt khi:** người kiểm độc lập có thể nói chính xác cách setup/quan sát và tiêu chí đạt, không phải hỏi thêm để tự quyết expected behavior. Đây là khả năng kiểm chứng trên giấy; chưa cần test đã chạy trước khi có code.

**Không đạt khi:** thiếu tiêu chí Pass/Fail, thiếu expected outcome của output quan trọng, phương pháp quan sát không phân biệt được kết quả đúng/sai, hoặc còn để reviewer tự đặt ngưỡng nghiệp vụ/control.

**Ví dụ không đạt:** “không tạo trùng” nhưng chỉ kiểm response success. **Sửa:** với cùng normalized key và scope đã định, xác nhận số logical records, kết quả hai thao tác cạnh tranh và side effects theo contract. Không có access DB vẫn có thể chọn readback/API/inspection phù hợp, nếu đủ chứng minh outcome.

### 3.8. Q05 — Kiểm truy vết, phiên bản và khả năng sửa đổi

**Cách kiểm:**

1. Lập danh sách ID thuộc target: need/BR/AC/model/contract và selected scope. Kiểm ID duy nhất, refs resolve được, source/version đúng.
2. Đi ngược từ từng requirement tới nhu cầu/quyết định; đi xuôi tới model/AC/Story và verification condition theo giai đoạn. Kiểm dependency/shared rule theo cả hai chiều.
3. Phân biệt phần kế thừa với delta. Nội dung dùng chung có một nguồn chuẩn; bản sao có thể lệch phải bỏ hoặc thay bằng ref có version.
4. Trước triển khai, liên kết code/run có thể là “chưa có — chưa triển khai”; phải có planned allocation/verification. Sau triển khai, bổ sung PR/SHA/build/test run/verdict thực tế và đối soát baseline được kiểm.
5. Thử impact query bằng tay: đổi BR-X thì xác định được model/Story/test nào phải xem lại? Nếu không, finding chưa đóng. Đổi revision phải invalidate/check lại đúng phạm vi, không gắn kết quả cũ cho version mới.

**Evidence:** RTM/allocation table, ref integrity result, pin commit/selected-scope và một impact walkthrough.

**Đạt khi:** refs phù hợp giai đoạn đều truy được, không có yêu cầu đang thực hiện vô nguồn hoặc không có planned verification, và tìm được đối tượng phụ thuộc khi đổi. **Không đạt khi:** URL tồn tại nhưng trỏ revision khác, hoặc một label được dùng thay tất cả các quan hệ.

### 3.9. Q06 — Kiểm không mơ hồ và một nghĩa chấp nhận rõ

**Cách kiểm:**

1. Rà các từ/điều kiện có nhiều nghĩa: “hợp lệ”, “phù hợp”, “nhanh”, “tất cả”, “hiện tại”, “v.v.”, “và/hoặc”, “nếu cần”. Mỗi từ phải được định nghĩa hoặc thay bằng rule/giá trị/constraint có ref.
2. Chốt actor, đối tượng, phạm vi quantifier, đơn vị, timezone, normalization, thứ tự priority và thời điểm áp dụng. Không để “khách hàng trùng” vừa nghĩa cùng tên vừa nghĩa cùng MST ở hai nơi.
3. Tách các nghĩa độc lập thành ID có thể review/verify riêng. Một constraint nguyên tử như transaction phải ghi state + audit nhất quán có thể chứa nhiều effect; không tách máy móc làm mất invariant.
4. Cho Dev và QA diễn giải độc lập cùng requirement bằng một ví dụ. So phần điều kiện/expected result; nếu khác nhau, hỏi source/authority và sửa diễn đạt, không chỉ ghi “đã trao đổi miệng”.
5. Kiểm template/naming/section phù hợp và nội dung hiểu được với người dùng hồ sơ. Sửa typo/alias nếu làm thay đổi nghĩa hoặc refs.

**Evidence:** glossary/normalized statement, clarification decision, read-back của người nhận và finding closure.

**Đạt khi:** các điểm có thể gây cách hiểu khác đã được giải quyết; người nhận có thể mô tả cùng hành vi/giới hạn từ hồ sơ. **Không đạt khi:** chỉ đồng ý “đã hiểu” mà Dev/QA đưa expected result khác nhau.

**Ví dụ:** “AM sửa được hồ sơ của mình” phải xác định “của mình” là creator hay current owner, các state được sửa, field nào và xử lý ownership đổi giữa chừng nếu áp dụng.

### 3.10. Q07 — Kiểm khả thi và đúng mức bàn giao

**Cách kiểm:**

1. Dev/TL đối chiếu yêu cầu với code/data/interfaces/constraints hiện tại; ghi solution delta và cơ sở nhận định. Không coi việc tên API có trong tài liệu là API đã tồn tại/được phép dùng.
2. Kiểm dependency owner/counterpart, quyền, giới hạn hệ ngoài, dữ liệu/môi trường và khả năng quan sát kết quả. Ghi commitment hoặc blocker.
3. Với điều chưa biết có thể làm thay đổi feasibility/expected behavior, thực hiện khảo sát/PoC/benchmark phù hợp rủi ro, hoặc giữ scope ở trạng thái chưa đạt. Không tạo Task phân tích mặc định; nghiên cứu có thể nằm trên Epic, Task kỹ thuật độc lập chỉ khi cần output/timebox được lập kế hoạch riêng.
4. QA xác nhận phương pháp kiểm khả thi; PM/leads kiểm estimate, capacity và mốc bàn giao. Requirement phải mô tả what/constraint đúng cấp; giải pháp how để trong solution, trừ constraint đã được chấp thuận.
5. Ghi feasibility verdict và assumptions còn lại. Assumption ảnh hưởng nội dung bắt buộc phải được giải quyết hoặc theo cơ chế được cấp có thẩm quyền duyệt; không dùng một nhãn risk accepted để tuyên bố điều chưa biết là đã chứng minh được.

**Evidence:** solution/constraint refs, reality check hoặc PoC khi cần, dependency commitment, verification feasibility và estimate rationale.

**Đạt khi:** có cơ sở hợp lý để thực hiện/kiểm chứng phần được giao trong constraint và không còn blocker quan trọng bị che. Chứng minh ở mức đủ cho bàn giao, không phải đã viết xong mọi dòng code. **Không đạt khi:** chỉ ghi “AI có thể làm” hoặc “sẽ xin quyền sau” dù quyền đó quyết định giải pháp có làm được không.

### 3.11. Cách xác định mẫu số và điều kiện dừng theo loại hồ sơ

Bảng này áp dụng Q02/Q03/Q04 cho D01–D10. Owner phải tạo inventory cụ thể của Epic/Story đang review; các chữ “mọi”, “đủ”, “phù hợp” trong tiêu chí chỉ được kết luận sau khi có tập item và disposition bên dưới.

| Hồ sơ | Inventory/đơn vị cần rà | Reviewer thực hiện | Điều kiện dừng để kết luận ở mức đặc tả |
|---|---|---|---|
| D01 Flow | Actor/trigger/use case; step/decision; nhánh success/alternate/exception; wait/retry nếu có | Lần theo từ trigger tới postcondition; tại mỗi decision xét condition overlap/default; tại mỗi giao tiếp xét lỗi trước/sau effect | Không có bước/nhánh bắt buộc vô chủ hoặc không biết kết quả; các loop/wait áp dụng có điều kiện kết thúc; đường quan trọng có scenario |
| D02 State | Tập state × command; guard partitions; replay/stale/concurrency khi áp dụng | Điền từng ô thành valid transition/no-op/denied/infeasible có reason; đối chiếu diagram/table/permission; thêm guard-fail conditions | Mọi ô của tập state–command được chọn có disposition; transitions có target/effect; các guard/exception quan trọng có expected result và verification condition |
| D03 Decision | Domains của conditions; các rule/tổ hợp khả thi; overlap/default | Lập bảng đầy đủ hoặc compact có lý do gộp; so constraint loại trừ và ưu tiên; chọn witness input cho mỗi rule | Không còn tổ hợp khả thi chưa biết outcome; overlap/default rõ; mỗi rule trong scope có ít nhất một witness hoặc lý do chứng minh infeasible |
| D04 Data | Fields/schema/relationships; required/default/domain; valid/invalid groups và boundaries | Rà field một lượt, rồi cross-field/uniqueness/normalization; thử witness tại biên và các giá trị đặc biệt | Không còn field/constraint áp dụng thiếu meaning/domain/outcome; mỗi nhóm/biên chọn có expected behavior, hoặc N/A có lý do |
| D05 Permission | Actor groups × action × resource/data-scope/condition; default deny/allow theo policy | Kiểm allow, wrong role, wrong owner/state/tenant và privilege change nếu áp dụng; so server/UI/AC | Mọi lớp quyền có disposition; những lớp được gộp có cùng rule được xác nhận; không chỉ có các role được cho phép |
| D06 UI | Screens/actions/fields; empty/loading/error/success/disabled và navigation liên quan | Walkthrough mockup với inputs/permission/state; so contract và outcome server | Mọi UI state áp dụng có behavior; không có nút/field làm phát sinh rule chưa được quyết định |
| D07 Integration | Operations/events, hai đầu contract, commit boundaries; timeout/failure/duplicate/order | Diễn tập request thành công, lỗi trước/sau commit và mất response; chỉ rõ retry/recovery owner | Caller/callee biết response/effects/retry cho từng nhóm lỗi áp dụng; unknown có thể đổi contract không được để qua gate |
| D08 Edge | Cases phát hiện từ flow/state/data/permission/integration và nguồn vận hành | Với từng case ghi precondition/trigger/result/risk; kiểm vào AC/model nào; tìm case đặc biệt từ stakeholder/QA | Không có case trong scope chỉ có tên mà thiếu outcome; không có case bị loại mà thiếu reason/authority; không còn unknown chặn |
| D09 NFR/transition | Control/metric và điều kiện đo; migration/reconcile/recovery obligations | Điền verification method, environment/data, threshold/control và owner; thử giải thích điều gì làm fail | Mọi obligation áp dụng có cách chấp nhận; không dùng “sẽ đo sau” thay ngưỡng/điều kiện chưa được chốt |
| D10 Solution/allocation | Components/delta/contracts, assumptions/dependencies; BR/AC → Story allocation | Read-back solution và tác động, kiểm reality/dependency; thử đi từ rule đến Story/verification | Không có gap scope/assumption chặn; feasible cho scope chọn; các Story không bỏ rule bắt buộc hoặc tính scope trùng |

**Mẫu số không phải số dòng trong một template trống.** Ví dụ state coverage dùng tập state/command được phân tích và xác nhận; nếu còn thiếu một command nghiệp vụ do chưa hỏi đúng stakeholder thì bảng 100% ô hiện có vẫn không chứng minh Q02 Đạt. Vì vậy bước source/actor review luôn đi trước kiểm bảng.

### 3.12. Ví dụ kiểm đủ state transition: từ nhận xét tới finding có căn cứ

Dùng Epic minh họa tại mục 9: 5 business states và 4 command. Với **operation mới**, inventory có 5 × 4 = 20 cặp state–command:

| State / command mới | submit | approve | reject | cancel |
|---|---|---|---|---|
| Draft | TR-01 nếu guard đạt | Denied | Denied | TR-04 nếu guard đạt |
| PendingApproval | Denied | TR-02 nếu guard đạt | TR-03 nếu guard đạt | Denied |
| Approved | Denied | Denied | Denied | Denied |
| Rejected | Denied | Denied | Denied | Denied |
| Cancelled | Denied | Denied | Denied | Denied |

**Reviewer phải làm tiếp, không dừng ở bảng này:**

1. Xác nhận với Business rằng 5 states/4 commands đúng và các terminal state không có reopen/resubmit trong scope.
2. Đối chiếu 4 ô transition với diagram, guard và side effects. 16 ô còn lại phải có rule từ chối và contract/error group, không chỉ bỏ trống.
3. Với TR-01, liệt kê guard partitions: đúng/sai auth, role, owner, data, current state/version; thứ tự lỗi theo decision rules. Dùng trường hợp chỉ một điều kiện sai khi cần để không che lỗi.
4. Xét replay riêng với operation đã ghi, không nhập nhằng với submit mới ở PendingApproval. Cùng key/payload, key trùng payload khác, đổi quyền, mất response và hai key cạnh tranh đều có expected result theo applicability.
5. Map các dòng và nhóm guard/failure tới AC/test conditions của scope Story. Story submit chọn cột submit và related guards/replay; approve/reject/cancel có allocation khác. Spec Epic vẫn giữ model chung.
6. Ghi finding: ví dụ `F-STATE-01: PendingApproval × cancel chưa có disposition/decision`. Chỉ đóng khi có decision + model/contract/AC refs đã sửa và reviewer kiểm lại.

**Kết luận được phép:** 20/20 cặp đã có disposition, 4 transition có guard/effect, những nhóm guard/replay/failure áp dụng có outcome và allocation, nguồn/authority đã xác nhận. Đây là coverage của mô hình/đặc tả đã rà, chưa phải 20 test đã chạy hoặc chứng minh mọi tổ hợp toàn hệ thống.

**Chưa được kết luận Đạt nếu:** còn một command chưa xác nhận, ô denied chưa biết response/effect, hoặc chỉ có success paths. Không chấm “có sơ đồ state machine” là đủ.

**Áp dụng ngay vào ví dụ mục 9:** mục 9.3 vẫn để thời hạn giữ operation result và giới hạn key cho spec thật chốt sau. Nếu các giá trị này quyết định retry/contract trong scope Story, Q02 chưa đạt cổng baseline dù bảng 20 ô đã đầy đủ. Q01 cũng chưa được coi Đạt vì các rule ví dụ chưa có Business authority thật xác nhận. Đây là ví dụ học cách đặc tả/review, không phải một hồ sơ đã được duyệt để triển khai.

### 3.13. Mẫu record review để member thực hiện nhất quán

```text
Review target / selected scope / input revision:
Nguồn/actor/authority đã rà:
Model/requirement inventory version:
Check IDs: Q01..Q07 và D01..D10 áp dụng
Item ID / source ref / output ref:
Thao tác kiểm đã làm / witness hoặc counterexample:
Expected outcome / actual finding trong tài liệu:
Verdict: Đạt | Không đạt | Chưa kiểm | N/A có lý do
Finding ID / severity theo mức chặn / owner / due:
Decision/correction ref / reviewer closure / reviewed revision:
Inventory counts: total / disposed / unknown / missing verification mapping
Gate impact: cho bước nào, phần nào còn bị chặn
```

**Phân biệt kết quả tài liệu với kết quả phần mềm:** trước code, reviewer ghi đối chiếu spec/model, không ghi test runtime Pass. Sau code, test reports/build/verdict là evidence khác. Việc thiết kế skill sau này phải giữ ranh giới này; skill không được biến review checklist thành bằng chứng sản phẩm đã hoạt động.


## 4. Epic cần làm rõ những hạng mục nào?

**B = phải có nội dung cốt lõi. C = có điều kiện; phải quyết applicability.** Không có nghĩa bắt buộc tạo một file cho mỗi dòng.

| ID | Hạng mục Epic | Output tối thiểu | Tiêu chí đủ để review | Owner / reviewer chính |
|---|---|---|---|---|
| E01 — B | Mục tiêu, nguồn, scope | Feature refs, business outcome, trong/ngoài scope và acceptance cấp Epic | Biết giải quyết vấn đề gì, ai nhận giá trị, ranh giới ở đâu và thế nào là kết quả đạt | BA / Business + PM |
| E02 — B | Actor, thuật ngữ, đối tượng | Actor/system list, glossary, entity/ownership và invariant liên quan | Không dùng cùng một từ cho hai nghĩa; biết ai/đối tượng nào tham gia | BA / Business + Dev |
| E03 — B | Business flow và use cases | Trigger, pre/postconditions, main/alternate/exception flows có step IDs | Các đường đi chính và lỗi quan trọng có kết quả cuối, người chịu trách nhiệm; xem D01 | BA / Business + Dev/QA |
| E04 — C | Business state/lifecycle | State definitions, transition/command matrix, guards và forbidden behavior | Đủ trạng thái/sự kiện trong scope; biết valid, denied/no-op và side effects; xem D02 | BA + Dev / Business + QA |
| E05 — B | Rule và tổ hợp quyết định | BR IDs; decision table khi nhiều điều kiện ảnh hưởng kết quả | Có priority/default; không chồng lấn mâu thuẫn hoặc bỏ sót tổ hợp khả thi; xem D03 | BA / Business + Dev/QA |
| E06 — B | Data và validation | Từ điển dữ liệu của đối tượng/delta; source, validation, relationships | Chốt bắt buộc, format, normalization, uniqueness và boundary liên quan; xem D04 | BA + Dev / Business + QA |
| E07 — B | Quyền và phạm vi dữ liệu | Actor/action/resource/condition matrix; quyền xem/sửa trường nếu có | Biết ai được/không được làm gì trên dữ liệu nào, kiểm tại server; xem D05 | BA + Dev / Business + security/QA |
| E08 — C | UI và trải nghiệm | Flow màn hình/mockup version, input/output/error/empty/loading states | Không dùng ảnh thay rule; UI phản ánh đúng contract và quyền; xem D06 | BA/UX / Business + Dev/QA |
| E09 — C | Integration và contract | Interfaces, ownership hai đầu, schema/version/error/retry refs; sequence khi cần | Chốt failure/timeout/duplicate/order và boundary giao tiếp; xem D07 | Dev/TL / counterpart + QA |
| E10 — B | Ngoại lệ và edge cases | Catalogue theo rủi ro, từng case có expected result hoặc N/A có lý do | Không chỉ liệt kê tên lỗi; tác động dữ liệu/state/side effect và recovery rõ; xem D08 | QA + BA/Dev / authority tương ứng |
| E11 — C | NFR/control | Metric, ngưỡng, workload/environment, cách đo; constraint bắt buộc | Có thể kiểm chứng; không dùng ngưỡng tự chọn chưa được duyệt; xem D09 | BA + TL/QA / Business + control owner |
| E12 — C | Migration/vận hành | Mapping, reconcile, cutover/restore/rollback và support impact | Có data authority, tolerance và tiêu chí chuyển giao liên quan; xem D09 | Migration/Release / Data Steward + Ops/QA |
| E13 — B | Solution và dependency | Hiện trạng→delta, design/contract refs, assumptions/risk và owner/commitment | Khả thi cho scope chọn; không để dependency chưa xác nhận thành “Ready”; xem D10 | Dev / TL/peer + QA |
| E14 — B | AC, coverage và test approach | AC cấp Epic, scenario/test conditions, trace các mô hình/rule | Biết kiểm cả mục tiêu tổng thể và luồng liên Story; planned coverage không bị gọi là test đã pass | BA + QA / Business + Dev |
| E15 — B | Phương án Story | Outcome từng Story, selected BR/AC/model refs, dependency và estimate | Không chia bỏ rule an toàn bắt buộc; không gap/đếm lặp; INVEST hỗ trợ review | BA + Dev + QA / PM |
| E16 — B | Decision, review và baseline | Decision/question log, applicability, reviewer verdict, manifest và version refs | Không còn câu hỏi chặn scope chọn; PM chốt đúng revision trước merge/spawn | BA điều phối / chuyên môn + PM |

Ví dụ E04 có thể N/A cho sửa copy thuần túy, nhưng không được N/A cho luồng duyệt vì chưa nghĩ ra vòng đời. E08 có thể N/A cho backend-only nếu đã xác nhận không có UI delta. E11/E12 vẫn phải rà tác động, không mặc định bỏ qua vì tên Epic không nói đến NFR/migration.

## 5. Story cần đầy đủ những hạng mục nào?

Story có mức chi tiết đủ để Dev/QA triển khai, không phải SRS viết lại toàn Epic. Mỗi phần có thể ghi **delta cụ thể** hoặc **link tới section/model đã baseline**.

| ID | Hạng mục Story | Nội dung cần có | Tiêu chí review |
|---|---|---|---|
| S01 | Định danh và baseline | Feature/Epic, logical/Jira ID, baseline commit + selected scope | Không trỏ “latest”; xác định chính xác phần được phép làm |
| S02 | Outcome và scope | Actor, mục tiêu, giá trị, trong/ngoài scope | Một phần hành vi kiểm chứng được; không chỉ là tên màn hình/API |
| S03 | Trigger và pre/postconditions | Điều kiện bắt đầu, sự kiện/kênh gọi, kết quả sau thành công/thất bại | Test có thể setup dữ liệu/state và biết kết quả cần kiểm |
| S04 | Flow được chọn | Step IDs từ Epic, alternate/exception trong scope và delta | Không phải suy đoán bước giữa; nhánh kết thúc/phản hồi rõ |
| S05 | Rule/state/decision subset | BR IDs, transition/decision rule IDs, expected illegal/denied behavior | Quy tắc chung đủ rõ, không tạo biến thể mâu thuẫn Epic; N/A có lý do |
| S06 | Data và quyền | Fields/schema/normalization/validation, actor-resource constraints liên quan | Biết positive/negative/boundary và quyền truy cập thực tế |
| S07 | UI/API/contract/solution | Version refs và delta: request/response, error, state changes, side effects | Có đủ contract để code/test, gồm lỗi/đồng thời khi áp dụng |
| S08 | Edge/NFR/transition impact | Selected cases/controls, thresholds và cách kiểm; chỉ rõ N/A | Không bỏ case bắt buộc vì đang chia Story nhỏ |
| S09 | AC và ví dụ | AC IDs gắn input/action/expected result, trace BR/model/case | Mọi AC có cách kiểm chứng; không dùng “đúng theo yêu cầu” làm AC |
| S10 | Verification approach | Test conditions theo rủi ro, test data/environment, oracle và evidence cần | QA xác nhận expected result độc lập; chưa cần mọi script đã viết |
| S11 | Dependency, ownership, estimate | Dev/QA owners, reviewer, dependency/commitment, estimate/capacity và câu hỏi | Đủ DoR để thực hiện; phần chưa sẵn có kế hoạch nhưng không che blocker |
| S12 | Completion và change refs | DoD policy áp dụng, approval refs, open decisions và change rules | Biết ai chốt và evidence nào cần để Done; không còn câu hỏi chặn |

**Thời điểm:** trước spawn phải có kế hoạch Story và nội dung baseline đủ rõ cho scope chọn; sau spawn có thể hoàn thiện phân công/dữ liệu/slot/capacity trước DoR. Không dùng “sẽ làm rõ khi code” cho quyết định làm thay đổi hành vi.

## 6. Hướng dẫn chi tiết cho từng loại mô hình/hồ sơ

### D01. Flow, use case và swimlane

**Khi dùng:** mọi hành vi cần có mô tả flow; dùng sơ đồ khi giúp nhìn rõ nhánh/phối hợp. Luồng nhiều phòng ban/hệ thống nên dùng swimlane/BPMN phù hợp; flow ngắn có thể dùng danh sách bước hoặc flowchart.

**Trường tối thiểu:** flow ID, mục tiêu, actor/participants, trigger, preconditions, main steps, alternate/exception paths, postconditions, dữ liệu trao đổi và BR/AC refs.

**Review đủ:**

- [ ] Mọi bước có actor/system thực hiện và output, không có bước “xử lý tiếp” vô chủ.
- [ ] Mỗi điểm rẽ có điều kiện rõ, xử lý overlap/default hoặc trường hợp không điều kiện nào đúng.
- [ ] Có lối thành công, từ chối và lỗi quan trọng; không có nhánh cụt không giải thích.
- [ ] Wait/timeout/retry/cancel và handoff qua bên khác được quyết applicability.
- [ ] Biết dữ liệu/state nào được ghi và side effect nào phát sinh ở từng điểm quan trọng.
- [ ] Điều kiện đầu/cuối khớp business state, permission matrix, contract và AC.

**Không đạt:** sơ đồ chỉ có “Nhập → Xử lý → Thành công”; thiếu kiểm quyền, validation hoặc lỗi lưu. Không bắt vẽ cả flowchart lẫn BPMN cho cùng một thông tin nếu một mô hình đã đủ và rõ.

### D02. State transition và vòng đời nghiệp vụ

**Khi dùng:** đối tượng có lifecycle, trạng thái quyết định action được phép, hoặc sự kiện/approval làm thay đổi trạng thái. State nghiệp vụ khác trạng thái màn hình tạm và status Jira.

**Trường tối thiểu:** entity, state ID/name/meaning, initial/terminal states, invariant; transition ID, source, event/command, actor, guard, target, data changes/side effects; hành vi khi guard fail hoặc command không hợp lệ.

| Transition ID | Từ state | Event / actor | Guard | Sang state | Output / side effect | Khi bị từ chối / N/A |
|---|---|---|---|---|---|---|
| TR-… | … | … | … | … | … | … |

**Review đủ:**

- [ ] State có nghĩa khác nhau, có đường đi tới được và invariant rõ; initial/terminal và đường phục hồi đã được xét.
- [ ] Với mỗi state và command trong scope, ghi disposition: transition, no-op/replay, denied hoặc không khả thi có lý do; không để ô trống vì chưa biết.
- [ ] Guard và quyền được tách rõ: đúng role chưa đủ nếu state/ownership không đúng.
- [ ] Ghi kết quả khi nhận command sai thứ tự, lặp, stale hoặc hai command cạnh tranh.
- [ ] Diagram và bảng transition cùng một tập ID/version; nếu khác nhau phải sửa trước review đạt.
- [ ] QA có test condition cho chuyển hợp lệ và những lệnh bị cấm/guard fail theo risk scope; không chỉ kiểm có đi qua từng state.

State diagram và state table giúp nhìn vòng đời từ hai góc. Bảng chi tiết phải giải thích cả hành vi từ chối; chỉ vẽ mũi tên hợp lệ chưa đủ để Dev tự quyết lỗi trả về. Các nguyên tắc mô hình sự kiện/điều kiện và rà transition tham khảo ISTQB; bộ trường/review này là quy định CRM. [ISTQB CTFL, 4.2.4](https://istqb.org/wp-content/uploads/2024/11/ISTQB_CTFL_Syllabus_v4.0.1.pdf).

### D03. Business rules và decision table

**Khi dùng:** mọi rule có ID và nguồn; bảng quyết định cần khi nhiều điều kiện ảnh hưởng kết quả hoặc có ưu tiên/ngoại lệ dễ bỏ sót.

**Trường tối thiểu:** BR ID, source/authority, điều kiện/phạm vi, kết quả, ngoại lệ, priority/default; với decision table có condition domains, rule rows/columns và expected actions.

**Review đủ:** điều kiện được định nghĩa; tổ hợp khả thi trong scope có kết quả; tổ hợp bị loại có constraint chứng minh; rule chồng lấn có priority hoặc cùng kết quả đã xác nhận; có default; ví dụ không mâu thuẫn flow/state/data/permission.

Không cần brute-force mọi tổ hợp toàn hệ thống. Nhóm điều kiện/tối giản phải giữ đúng nghĩa và có lý do; QA/Business xác nhận phần được gộp và residual risk. Bảng mẫu dùng dạng một dòng cho một rule là cách trình bày của CRM, không bắt buộc cùng layout mọi nguồn.

### D04. Data dictionary, validation và ranh giới dữ liệu

**Khi dùng:** mọi input/output/persisted data mới hoặc thay đổi; có thể tham chiếu contract đã baseline nếu không đổi.

**Trường tối thiểu:** field/entity, meaning, type/unit/precision/timezone, source/owner, required/default/null behavior, valid domain/length/range, normalization, relationship/uniqueness, error outcome và data/privacy handling liên quan.

**Review đủ:**

- [ ] Phân biệt absent/null/empty/whitespace, zero/negative và default nếu có ý nghĩa khác nhau.
- [ ] Chốt thứ tự normalize → validate → compare/store và kênh nào phải áp dụng cùng rule.
- [ ] Chốt khóa duy nhất, soft-delete/status scope, referential rules và concurrency liên quan.
- [ ] Các khoảng có đầu mút đóng/mở, đơn vị, làm tròn và timezone rõ; cross-field validation có điều kiện.
- [ ] QA có nhóm hợp lệ/không hợp lệ và boundary theo đúng domain; invalid inputs độc lập khi cần để nhìn ra lỗi.

Ví dụ giả định field số nguyên cho phép `[1,100]`: xét các nhóm dưới miền/trong miền/trên miền và các điểm `0,1,2,99,100,101`. Đây là ví dụ lập test conditions, không đặt ngưỡng thật cho CRM. Với chuỗi/tiền/ngày, phải dùng biên phù hợp kiểu dữ liệu, không áp máy móc công thức số nguyên.

### D05. Permission matrix và phạm vi dữ liệu

**Khi dùng:** mọi Story phải biết actor và quyền áp dụng; backend-only vẫn cần đánh giá.

**Trường tối thiểu:** role/principal, action, resource/object, ownership/tenant/data scope, state/condition, field restriction, allow/deny outcome và source authority.

**Review đủ:** có positive/negative cases; xét role đúng nhưng resource/state sai; server enforcement không chỉ ẩn nút UI; delegation/self-approval nếu có; data exposure và error message không làm lộ ngoài phạm vi; role/ownership đổi trong lúc thao tác có kết quả xác định nếu áp dụng.

Quyền dùng chung tham chiếu version chung. Story không được giảm kiểm quyền để tách thành phần nhỏ hơn.

### D06. UI/UX và quan hệ với contract

**Khi dùng:** có màn hình/tương tác người dùng bị thay đổi.

**Trường tối thiểu:** screen/version, entry/navigation, field/action, visibility/editability, success/error/empty/loading/disabled states; copy/validation và accessibility/usability criteria liên quan.

**Review đủ:** UI khớp flow/data/quyền; biết xử lý double click, chờ lâu, lỗi server và input không hợp lệ; field error và server error không bị đồng nhất; nếu upload/pagination/search có giới hạn thì phải rõ. Mockup là hình minh họa, không đủ thay decision table hoặc API contract.

### D07. API/integration contract và sequence

**Khi dùng:** có giao tiếp UI/API/module/hệ ngoài/async. Sequence diagram cần khi thứ tự, callback, commit và retry khó diễn đạt bằng vài bước; không bắt vẽ cho mọi API CRUD đơn giản.

**Trường tối thiểu:** producer/consumer owners, operation/version, request/response/schema, auth/permission, pre/postconditions, error semantics, timeout/retry/idempotency/order, transaction/consistency và backward compatibility liên quan.

**Review đủ:** biết thành công ở điểm nào; timeout trước/sau commit; retry có tạo trùng không; side effects nào được đồng bộ/async; partial failure/recovery và observability; identity/correlation và data classification phù hợp. Các ngưỡng timeout/retry/rate phải được chốt, không để Dev/AI tự chọn như rule nghiệp vụ.

### D08. Exception, edge case và tính nhất quán khi có lỗi

**Khi dùng:** mọi Epic/Story rà các chiều dưới đây; chỉ giữ các case áp dụng, loại trừ có lý do và reviewer.

| Chiều rà soát | Câu hỏi cần quyết | Expected result phải nêu |
|---|---|---|
| Input/domain | Thiếu, sai định dạng, biên, Unicode, null/empty? | Validation, phản hồi và dữ liệu có thay đổi không |
| Permission/data scope | Sai role, khác owner/tenant, quyền vừa bị đổi? | Allow/deny, data exposure và server behavior |
| Business state/order | Action ở state sai, command cũ hoặc out-of-order? | Transition/no-op/deny, state/data cuối |
| Duplicate/retry | Double click, request lặp, mất response sau commit? | Cách nhận biết cùng operation và tránh effect ngoài ý muốn |
| Concurrency/stale | Hai người sửa/duyệt, version cũ? | Ai thành công, conflict, atomicity và dữ liệu cuối |
| Integration | Timeout, downstream lỗi, callback trễ/trùng? | Commit/rollback/compensation/retry và người xử lý |
| Volume/time | Tập rỗng/lớn, giới hạn page/file, timezone/cuối kỳ? | Giới hạn, precision/order, tính nhất quán và cách đo |
| Partial completion | Lưu xong nhưng audit/notification lỗi? | Kết quả nghiệp vụ, pending side effect, recovery/alert |
| Migration/recovery | Dữ liệu legacy sai, restore/restart giữa chừng? | Tolerance, exception/reconcile và cách tiếp tục |
| User interruption | Refresh/back/cancel phiên hết hạn? | Dữ liệu đã/chưa lưu, cảnh báo và khả năng tiếp tục |

Mỗi case có ID, trigger/precondition, expected result, BR/AC refs và risk/priority. “Cần test timeout” chưa là đặc tả đầy đủ. Phải quyết timeout ở đâu, dữ liệu có commit không, caller được retry thế nào và bên nào chịu trách nhiệm recovery.

### D09. NFR, migration và điều kiện vận hành

**NFR tối thiểu:** đối tượng/tác vụ, metric, threshold, workload/data volume, environment, thời điểm/cách đo và authority. Bảo mật/audit/retention/restore được diễn đạt bằng control kiểm chứng được, không buộc mọi yêu cầu chất lượng phải là số.

**Migration/transition tối thiểu khi áp dụng:** mapping/source version, Data Steward, quality thresholds, exceptions, trial/reconcile, cutover/rollback và ownership sau bàn giao. **Review đủ:** có người quyết dữ liệu, cách đối soát và điều kiện fail; không dùng “không mất dữ liệu” mà không định nghĩa tập dữ liệu và cách kiểm.

### D10. Solution, decomposition và testability

**Trường tối thiểu:** hiện trạng, delta/components/interfaces, phương án/rationale, contract refs, assumptions/risk, dependency owners và evidence feasibility; phương án Story có outcome, scope, BR/AC/model refs và estimate.

**Review đủ:** Dev/TL đọc lại rule bằng solution cụ thể; BA xác nhận hiểu khớp; QA nêu cách setup/observe/assert. Không cần thiết kế mọi dòng code trước baseline. Nếu chưa chứng minh được điều kiện quan trọng, ghi câu hỏi/blocker hoặc thực hiện nghiên cứu có timebox; không dùng từ “solution checked” để che giả định.

INVEST hỗ trợ review cách chia Story; nó không xác nhận toàn bộ model/contract đúng hoặc tự chứng minh Story đã đạt DoR.

## 7. AC, scenario và kiểm tra coverage trước khi bàn giao

### 7.1. Mẫu AC có thể kiểm chứng

```text
AC-ID:
Source: BR / flow step / transition / decision rule / NFR IDs
Precondition: actor, resource, state/version, dữ liệu và điều kiện môi trường
Action: command/event cụ thể qua kênh nào
Expected:
  - Response / UI / observable result
  - State và dữ liệu thay đổi hoặc không thay đổi
  - Side effects/audit/notification nếu có
  - Behavior khi lỗi, lặp hoặc bị từ chối nếu thuộc AC
Verification: API/UI/data/event/log hoặc phương pháp phù hợp
```

Given/When/Then có thể dùng để diễn đạt; không bắt mọi tổ hợp thành Gherkin dài nếu bảng quyết định rõ hơn. Một AC có thể cần nhiều testcase. Testcase triển khai chi tiết phải giữ trace và expected result, không tạo rule mới.

### 7.2. Chuỗi truy vết và bảng coverage

```text
Nhu cầu/Feature
  → Epic scope + BR + flow/state/decision/data/permission/NFR
  → Story selected scope + AC
  → Test condition / scenario dự kiến
  → Testcase/script
  → Test run + build + evidence + verdict
```

Đây là các liên kết của cùng công việc, không phải hai bộ requirement độc lập. Story dùng AC của mình để cụ thể hóa phần được chọn từ Epic; Task là cách tổ chức thực hiện, không là nguồn rule mới.

| Model / rule item | Outcome cần kiểm | Story / AC | Test condition dự kiến | Gap / quyết định |
|---|---|---|---|---|
| TR-01 submit hợp lệ | Đổi state và ghi đúng một logical operation | Story… / AC… | SCN… | … |
| PM-… deny wrong owner | Không đổi state/data; response đúng | Story… / AC… | SCN… | … |
| DAT-… maximum length | Biên hợp lệ và vượt biên | Story… / AC… | SCN… | … |

Trước baseline chỉ có thể xác nhận **planned coverage**, chưa được ghi test đã pass. Khi code/test chạy mới có executed coverage và evidence.

### 7.3. Kiểm theo từng loại coverage

| Đối tượng | Đơn vị cần kiểm/đếm trong scope | Cách xác nhận đủ để bàn giao |
|---|---|---|
| Flow | Main/alternate/exception path đã xác định | Mỗi đường quan trọng có kết quả và scenario; loop/timeouts có giới hạn/termination được quyết |
| Business state | State, valid transition, denied/guard-fail command và chuỗi rủi ro | Liệt kê tách các tập này; không gọi “đi qua đủ state” là đã xét đủ transition |
| Decision | Các rule/tổ hợp khả thi sau gộp có lý do | Mỗi expected action có case; tổ hợp loại trừ có constraint; overlap/default đã giải quyết |
| Data | Equivalence groups và boundary áp dụng | Có valid/invalid/biên; các tổ hợp cross-field quan trọng không bị bỏ qua |
| Permission | Các nhóm actor/action/resource/condition trong scope | Cả allow/deny, khác owner/state/tenant nếu có |
| NFR/integration | Các control/failure/performance condition liên quan | Có acceptance method, environment/data và authority; chưa có số đo thì chưa tuyên bố đã đạt |
| Requirement/AC | BR/AC được chọn | Không có rule áp dụng mà không biết Story/verification nào thực hiện; không có AC không truy được nhu cầu hoặc quyết định |

QA đề xuất scope/độ sâu kiểm theo risk; Business/TL xác nhận phần nghiệp vụ/kỹ thuật; PM kiểm residual risk và thiếu sót trước chốt. Không yêu cầu mọi đường đi vô hạn hay mọi tổ hợp toàn hệ thống đều được liệt kê. Mọi giảm phạm vi kiểm có lý do và authority, không được dùng để bỏ rule bắt buộc.

## 8. Quy trình review: bảo đảm nội dung được xác nhận bởi đúng người

| Bước | Ai làm? | Kiểm gì? | Đầu ra |
|---|---|---|---|
| 1. Xác định applicability | BA với Dev/QA và chuyên gia liên quan | E01–E16/S01–S12 áp dụng đến đâu, model nào cần, tài liệu nào tái sử dụng | Coverage/applicability list; N/A có lý do |
| 2. Discovery | BA/Business, Dev/QA cùng tham gia | Rule/ví dụ/câu hỏi, context và rủi ro; mô hình có đủ nhánh chưa | Draft và decision queue |
| 3. Read-back và phản biện | Dev/TL + QA | Dev giải thích solution; QA đề xuất case sai/biên/đồng thời; BA so với ý nghĩa nghiệp vụ | Findings và sửa mô hình/contract/AC |
| 4. Kiểm chéo | BA + Dev + QA | Cùng action có cùng guard/permission/data/state/error ở flow, model, contract và AC không | Cross-model findings đã xử lý |
| 5. Xác nhận nội dung | Business/technical/control authority | Expected result, rủi ro và constraint đúng thẩm quyền | Specialist verdict đúng revision |
| 6. PM review bàn giao | PM | Đủ output, hết blocker, phân rã hợp lý, baseline scope/manifest và approvals đúng version | Approve/return với lý do |
| 7. Merge và kiểm DoR | Người/service có quyền; Dev/QA nhận | Merge đúng nội dung đã review; Story pin refs; điều kiện thực hiện hiện tại đủ chưa | Baseline receipt, Story refs và DoR result |

Review thực hiện async trên Jira và PR; không cần họp đủ mọi role cho mọi hạng mục. Owner tổng hợp findings, reviewer xác nhận sửa; không coi comment rải rác là đã có kết luận.

### 8.1. Cổng trước tạo Story và cổng trước code

**Trước tạo Story:** phần Epic được chọn có model/rule/AC/solution/test approach đủ rõ; applicability và câu hỏi chặn đã xử lý; manifest được PM duyệt; bộ hồ sơ đó đã merge.

**Trước code:** Story xác định đúng subset/version, không có delta chưa duyệt; Dev/QA hiểu khớp; các điều kiện DoR còn lại như dữ liệu, dependency, quyền và capacity đã đạt. Có skeleton Story hoặc có AC chưa đủ để qua cổng này.

### 8.2. Kiểm máy được và phần cần con người

| Máy có thể kiểm cứng khi có dữ liệu/cấu hình tương ứng | Người chịu trách nhiệm xác nhận |
|---|---|
| Required sections/fields, ID duy nhất, ref không gãy, type/enum/schema | Nội dung đúng nhu cầu và thuật ngữ đúng nghĩa |
| Model refs hợp lệ, transition endpoint tồn tại, table/diagram IDs khớp khi có cấu trúc | Mô hình đã bao phủ các tình huống quan trọng; guards/default hợp nghiệp vụ |
| BR/AC/model → Story/test-condition links, unknown/N/A records | Expected result đúng, quyết định đúng quyền và risk scope hợp lý |
| Approval actor/revision/digest và baseline merge/manifest integrity | Solution khả thi, testcase có khả năng phát hiện lỗi và đủ kiểm độc lập |

Không lấy “AI review đạt” hoặc đủ số section làm gate duy nhất. Nội dung này chỉ xác định yêu cầu cho cơ chế kiểm; chưa thiết kế/cài skill hay hook thực thi.

## 9. Ví dụ liên kết Epic → Story → model → AC → test condition

**Tất cả tên/giá trị/rule trong ví dụ là giả định để minh họa cách đặc tả, chưa được duyệt cho CRM thật. Ví dụ chỉ khai triển các phần chính, không tự coi là bộ hồ sơ đã đủ điều kiện baseline.**

### 9.1. Epic: Gửi và xét duyệt yêu cầu mở mã dự án

- Entity: `ProjectCodeRequest`; actor: Requester và designated Approver.
- Scope: tạo draft, submit, approve, reject và cancel draft. Việc tạo mã dự án thật sau quyết định không được ngầm suy ra từ ví dụ.
- Invariant: mỗi hồ sơ có ID duy nhất và version; một logical submit không được chuyển state/audit/notification intent lặp do retry.
- Quyền giả định: Requester thao tác draft của mình; Approver được phân công và khác người tạo mới approve/reject.
- Epic gồm Story submit, Story quyết định duyệt và các phần còn lại theo manifest; Story submit không cần triển khai cả UI approve/reject.

### 9.2. Business state và transition

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> PendingApproval: submit [owner, valid data, current version]
    PendingApproval --> Approved: approve [assigned approver, not creator]
    PendingApproval --> Rejected: reject [assigned approver, reason]
    Draft --> Cancelled: cancel [owner]
    Approved --> [*]
    Rejected --> [*]
    Cancelled --> [*]
```

Sơ đồ Mermaid minh họa trạng thái, không phải một file UML/BPMN được xác nhận tuân thủ ký pháp. Bảng dưới bổ sung hành vi cụ thể; actor/guard đã được định nghĩa trong rule và permission matrix.

| ID | Source / command | Điều kiện cho phép | Target / effect | Khi không đạt |
|---|---|---|---|---|
| TR-01 | Draft / submit | Requester là owner, dữ liệu hợp lệ, version hiện hành | PendingApproval, tăng version; ghi audit và durable notification intent | Từ chối theo nguyên nhân; không đổi dữ liệu/state |
| TR-02 | PendingApproval / approve | Assigned Approver khác creator, version hiện hành | Approved, tăng version, audit decision | Không đổi state/data; trả lỗi phù hợp |
| TR-03 | PendingApproval / reject | Assigned Approver khác creator, reason hợp lệ, version hiện hành | Rejected, tăng version, audit decision | Không đổi state/data; trả lỗi phù hợp |
| TR-04 | Draft / cancel | Requester là owner, version hiện hành | Cancelled, tăng version, audit decision | Không đổi state/data; trả lỗi phù hợp |

**Disposition cho các trường hợp còn lại:** command không được liệt kê hợp lệ tại state hiện tại bị từ chối, không đổi state; gồm submit ở Approved/Rejected/Cancelled, approve/reject ở Draft và cancel khi đã PendingApproval. Replay cùng idempotency key/payload/principal/resource đã thành công là trả kết quả đã ghi, không phải một transition mới. Trường hợp reopen/resubmit từ terminal state không thuộc scope ví dụ và không được tự cho phép.

Như vậy không còn ô “state sai thì Dev tự xử lý”. Trong spec thật cần contract/error cụ thể cho mọi nhóm từ chối; bảng sau minh họa phần submit.

### 9.3. Story: Owner gửi draft để chờ duyệt

**In scope:** command submit, permission, dữ liệu/version, retry/concurrency, response và notification intent. **Out of scope:** triển khai UI approve/reject; nhưng vòng đời và guard chung vẫn tham chiếu Epic.

Precondition của lần submit mới: hồ sơ Draft tồn tại, actor có quyền và là owner. Postcondition: hồ sơ PendingApproval đúng một lần, version tăng một đơn vị, audit và notification intent được ghi nhất quán.

#### A. Main flow và nhánh lỗi

```mermaid
flowchart TD
    A[Owner gửi Submit] --> B{Auth, resource và ownership hợp lệ?}
    B -- Không --> X[Từ chối, không đổi state]
    B -- Có --> C{Đã có key operation?}
    C -- Cùng payload --> R[Trả lại kết quả đã ghi]
    C -- Khác payload --> K[Conflict, không đổi state]
    C -- Chưa có --> D{Draft và version hiện hành?}
    D -- Không --> K
    D -- Có --> E{Dữ liệu hợp lệ?}
    E -- Không --> V[Validation error, không đổi state]
    E -- Có --> F[Ghi state, version, audit, intent và operation result nhất quán]
    F --> G{Commit thành công?}
    G -- Không --> Z[Lỗi lưu, không có thay đổi một phần]
    G -- Có --> H[Trả kết quả PendingApproval]
```

Replay được kiểm trước validation state/version của lần submit mới, nhưng sau authentication/authorization hiện tại: sau commit đầu tiên state đã đổi, retry được phép của cùng operation phải trả kết quả cũ; mất quyền thì không được dùng key cũ để đọc dữ liệu ngoài quyền. Việc gửi thông báo thật diễn ra nền; lỗi gửi không tự hủy quyết định submit đã commit. Dev chọn giải pháp phù hợp để bảo đảm contract này, không nhất thiết một thiết kế lưu trữ duy nhất.

#### B. Data và permission subset

| Item | Quy ước giả định | Nhóm cần kiểm |
|---|---|---|
| requestId | ID do hệ thống cấp, định danh một hồ sơ | Tồn tại/không tồn tại; request khác owner |
| expectedVersion | Số nguyên khớp version hiện hành cho operation mới | Khớp, stale, absent/invalid |
| projectName | Bắt buộc; trim đầu/cuối; 1–100 Unicode code points sau trim | Null/empty/whitespace, 1, 100, 101 code points và Unicode |
| idempotencyKey | Bắt buộc cho submit; scope theo principal + request + command | Replay payload khớp, key trùng payload khác, hai key cạnh tranh |
| permission | Requester có quyền và là owner mới submit | Sai role, đúng role nhưng sai owner, thiếu auth |

Các chính sách như thời hạn giữ operation result, giới hạn key và data retention phải được chốt trong spec thật trước baseline nếu ảnh hưởng contract/retry. Bảng mẫu không trao quyền để Dev/AI tự đặt chúng.

#### C. Decision/error rules cho submit

Các dòng được xét theo thứ tự; dòng sau chỉ áp dụng khi chưa trúng dòng trước. Response codes dưới đây là ví dụ contract, không phải quy định áp dụng sẵn cho CRM.

| ID | Điều kiện | Kết quả giả định |
|---|---|---|
| DR-01 | Thiếu/không hợp lệ authentication | 401, không đổi state/data |
| DR-02 | Không có resource phù hợp | 404 theo policy disclosure được duyệt |
| DR-03 | Actor không có quyền hoặc không là owner | 403, không đổi state/data |
| DR-04 | Có operation cùng key nhưng payload khác | 409, không tạo operation/transition mới |
| DR-05 | Có operation cùng key và payload khớp | Trả kết quả đã ghi; không tăng version/audit/intent lần nữa |
| DR-06 | Operation mới nhưng state hoặc version không hợp lệ | 409, không đổi state/data |
| DR-07 | Operation mới, state/version đúng nhưng data sai | 422, không đổi state/data |
| DR-08 | Các điều kiện đều đạt nhưng commit thất bại | Lỗi server; không có state/audit/intent ghi một phần |
| DR-09 | Các điều kiện đều đạt và commit thành công | Response thành công chứa state/version; ghi một logical transition |

Business/security authority phải review thứ tự lỗi và thông tin được tiết lộ; không chỉ “chọn code HTTP cho đủ”. Lỗi gửi notification sau commit thuộc xử lý nền và không rơi lại vào DR-08.

#### D. AC và test conditions trọng yếu

| AC | Kết quả cần đạt | Test conditions dự kiến |
|---|---|---|
| AC-SUB-01 | Submit mới hợp lệ: Draft → PendingApproval, tăng version một đơn vị, audit và intent nhất quán | Đúng owner/role/version/data; kiểm response, state, version và các record/effect liên quan |
| AC-SUB-02 | Sai auth/quyền/owner bị từ chối, không có thay đổi nghiệp vụ | Thiếu auth; sai role; đúng role nhưng khác owner; đối chiếu DR-01/03 |
| AC-SUB-03 | Data invalid không đổi state/data; error theo contract | Empty sau trim, biên 1/100 và vượt 101; kết hợp với input khác hợp lệ để không che lỗi |
| AC-SUB-04 | State sai hoặc stale version bị từ chối; không tăng version | PendingApproval với operation mới; từng terminal state; Draft với version cũ |
| AC-SUB-05 | Retry cùng operation trả kết quả cũ, không lặp logical side effects | Commit đã xong nhưng response bị mất; cùng key/payload; key cũ payload khác bị conflict |
| AC-SUB-06 | Hai operation mới cạnh tranh trên cùng version chỉ một lần chuyển thành công | Hai key trên cùng Draft/version; một thành công, một conflict; không có hai transition |
| AC-SUB-07 | Notification lỗi sau commit không đổi ngược state và có đường recovery | Intent đã lưu, gửi lỗi/timeout, retry notification không nhân đôi logical event |
| AC-SUB-08 | Commit lỗi không để dữ liệu nghiệp vụ/audit/intent thay đổi một phần | Mô phỏng lỗi tại boundary ghi; kiểm toàn bộ output/record theo contract |

Đây là planned conditions, chưa phải kết quả chạy test. Khi triển khai cần bổ sung testcase/data cụ thể, tiêu chí retry/retention và cách mô phỏng/quan sát phù hợp giải pháp được duyệt.

### 9.4. Vì sao ví dụ này rõ hơn một Story chỉ có mô tả?

- Dev biết transition và thứ tự replay/state validation, không tự đoán retry có phải lỗi không.
- QA biết kiểm state/data/side effects, không chỉ thông báo “Gửi thành công”.
- Business thấy quyền, ngoại lệ và kết quả khi từ chối để xác nhận có đúng mong muốn.
- PM thấy phạm vi Story submit, phần kế thừa từ Epic và câu hỏi còn phải chốt trước baseline.
- Skill sau này có bộ nội dung và tiêu chí để hỗ trợ; không có quyền tự quyết những phần còn thiếu.

## 10. Mẫu cấu trúc hồ sơ để sử dụng

### 10.1. Epic specification

```text
Epic ID / Jira key / Feature ref / revision
E01 Context, goal, scope và Epic acceptance
E02 Actors, glossary, entities và invariants
E03 Business flows/use cases với IDs, main/alternate/exception
E04 Lifecycle: state definitions + transition/command disposition
E05 BR catalogue + decision rules/table
E06 Data dictionary, validation, normalization và boundaries
E07 Permission/data-scope matrix
E08 UI/UX refs và states liên quan, hoặc N/A có lý do
E09 API/integration/sequence refs, hoặc N/A có lý do
E10 Exception/edge catalogue và expected outcomes
E11 NFR/control và acceptance methods, hoặc N/A có lý do
E12 Migration/operations impact, hoặc N/A có lý do
E13 Solution/dependency/feasibility
E14 Epic AC, planned coverage và test approach
E15 Story candidates, allocation, dependencies và estimate
E16 Questions/decisions/applicability/review + baseline manifest
```

### 10.2. Story specification

```text
S01 IDs + Epic/Feature + pinned baseline/selected scope
S02 Actor/outcome/in-scope/out-of-scope
S03 Trigger + preconditions + success/failure postconditions
S04 Selected flow steps + alternate/exception/delta
S05 Selected BR/transition/decision IDs hoặc N/A có lý do
S06 Data/permission subset và delta
S07 UI/API/contract/solution refs và implementation boundaries
S08 Selected edges/NFR/transition impacts hoặc N/A có lý do
S09 AC IDs + examples + expected observable outcomes
S10 Test conditions, data/environment và oracle/verification method
S11 Owners/reviewers/dependencies/estimate/capacity/questions
S12 DoD policy + approval/change refs
```

Không bắt mọi Story có file riêng: nội dung có thể là section trong Epic baseline và Jira Story trỏ đúng section/commit. Nếu dùng file riêng, phải giữ một nguồn nội dung chuẩn và link rõ, không duy trì hai bản spec khác nhau.

## 11. Ví dụ cách kết luận review đạt hoặc chưa đạt

| Hạng mục | Có nội dung nhưng chưa đạt | Đạt ở mức đặc tả khi |
|---|---|---|
| Flow | Có sơ đồ nhưng mọi lỗi đều tới một nút “Error” | Các nhóm lỗi/alternate quan trọng có expected outcome, owner và postcondition |
| State | Có các state và mũi tên hợp lệ | Biết guards, quyền, forbidden/no-op/replay và effect; diagram/table nhất quán |
| Edge case | Ghi “test double click, timeout” | Có preconditions, điểm thất bại, response/state/data/effects và cách recover |
| Data | Ghi “MST bắt buộc và duy nhất” | Định nghĩa normalize/domain, phạm vi uniqueness, trạng thái/legacy và concurrency liên quan |
| Permission | Ghi “chỉ AM tạo được” | Có ownership/data scope/server enforcement/deny outcomes liên quan |
| AC | Ghi “API hoạt động đúng” | Có input/action/output, source refs và cách kiểm chứng cụ thể |
| Solution | Có tên API/bảng DB | Giải thích delta, constraint, boundary, dependency/risk và đủ feasibility cho scope chọn |
| NFR | Ghi “nhanh và an toàn” | Có tiêu chí/điều kiện đo hoặc control, người xác nhận và phương pháp kiểm |

“Đạt ở mức đặc tả” chỉ xác nhận đầu vào đủ rõ cho bước sau. Nó khác “phần mềm đã đạt AC/DoD”, vốn cần evidence của review/code/test/bản chạy thực tế.

## 12. Các quyết định cần thống nhất trước khi thiết kế skill

1. Chấp thuận E01–E16 và S01–S12 như bộ kiểm nội dung của dự án, cùng applicability/N/A policy.
2. Chọn mẫu flow/state/decision/data/permission/AC phù hợp; không ép mọi trường hợp có mọi loại sơ đồ.
3. Chỉ định authority theo nội dung, người review và cách chốt expected result.
4. Thống nhất một nguồn chuẩn, pin/ref/ID và planned coverage trước baseline.
5. Thử review một Epic và một Story thực tế bằng bộ tiêu chí này; sửa những phần thiếu hoặc gây effort không có ích.
6. Sau khi nội dung và cách review ổn định mới xác định skill cần đọc/generate/check artifact nào, input/output ra sao và kiểm máy được đến đâu.

Thứ tự này giữ trách nhiệm quyết định ở người có thẩm quyền. Skill hỗ trợ đạt một chuẩn đã hiểu rõ; việc sinh đủ section không được dùng để tự xác nhận requirement đúng và đủ.
